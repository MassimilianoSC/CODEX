from fastapi import APIRouter, Request, Form, Depends
from fastapi.responses import RedirectResponse
from app.deps import require_admin, get_current_user               # updated import
from app.utils.save_with_notifica import save_and_notify

links_router = APIRouter(tags=["links"])

@links_router.post(
    "/links/new",
    status_code=303,
    response_class=RedirectResponse,
    dependencies=[Depends(require_admin)]
)
async def create_link(
    request: Request,
    title: str  = Form(...),
    url: str    = Form(...),
    branch: str = Form(...),
    role:  str  = Form("*")     # nuovo parametro, default "*"
):
    await save_and_notify(
        request=request,
        collection="links",
        payload={"title": title.strip(),
                 "url": url.strip(),
                 "branch": branch.strip(),
                 "role": role.strip().lower(),   # nuovo campo
                 },
        tipo="link",
        titolo=title.strip(),
        branch=branch.strip()
    )
    return RedirectResponse("/links", status_code=303)
