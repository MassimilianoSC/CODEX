from fastapi import APIRouter, Request, Form, Depends
from fastapi.responses import RedirectResponse
from app.deps import require_admin, get_current_user               # updated import
from app.utils.save_with_notifica import save_and_notify

contatti_router = APIRouter(tags=["contatti"])

@contatti_router.post(
    "/contatti/new",
    status_code=303,
    response_class=RedirectResponse,
    dependencies=[Depends(require_admin)]
)
async def create_contatto(
    request: Request,
    name: str    = Form(...),
    email: str   = Form(...),
    branch: str  = Form(...)
):
    await save_and_notify(
        request=request,
        collection="contatti",
        payload={"name": name.strip(),
                 "email": email.strip(),
                 "branch": branch.strip()},
        tipo="contatto",
        titolo=name.strip(),
        branch=branch.strip()
    )
    return RedirectResponse("/contatti", status_code=303)
