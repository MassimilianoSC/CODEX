from fastapi import APIRouter, Request, Depends, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from bson import ObjectId
from datetime import datetime

# 🔸 Niente più import da main.py!
from app.deps import get_current_user                       # ✅
# Usa sempre request.app.state.templates per i render        # ✅

notifiche_router = APIRouter(tags=["notifiche"])


# 🔹 Funzione da usare ovunque per creare una notifica
async def crea_notifica(
    request: Request,
    tipo: str,
    titolo: str,
    branch: str,
    id_risorsa: str,
):
    db = request.app.state.db
    await db.notifiche.insert_one(
        {
            "tipo": tipo,
            "titolo": titolo,
            "branch": branch,
            "id_risorsa": id_risorsa,
            "created_at": datetime.utcnow(),
            "letta_da": [],
        }
    )


# 🔹 Pagina con elenco completo delle notifiche non lette
@notifiche_router.get("/notifiche", response_class=HTMLResponse)
async def notifiche_page(request: Request, user=Depends(get_current_user)):
    db = request.app.state.db

    notifiche = (
        await db.notifiche.find(
            {
                "branch": {"$in": ["*", user["branch"]]},
                "letta_da": {"$ne": str(user["_id"])},
            }
        )
        .sort("created_at", -1)
        .to_list(None)
    )

    return request.app.state.templates.TemplateResponse(        # ✅
        "notifiche/index.html",
        {"request": request, "user": user, "notifiche": notifiche},
    )


# 🔹 Notifiche inline, mostrate in alto in ogni pagina
@notifiche_router.get("/notifiche/inline", response_class=HTMLResponse)
async def notifiche_inline(request: Request, user=Depends(get_current_user)):
    db = request.app.state.db
    notifiche = (
        await db.notifiche.find(
            {
                "branch": {"$in": ["*", user["branch"]]},
                "letta_da": {"$ne": str(user["_id"])},
            }
        )
        .sort("created_at", -1)
        .to_list(3)
    )

    return request.app.state.templates.TemplateResponse(        # ✅
        "notifiche/inline_partial.html",
        {"request": request, "notifiche": notifiche},
    )


# 🔹 API per segnare una notifica come "letta"
@notifiche_router.post("/notifiche/{id}/letta")
async def segna_letta(id: str, request: Request, user=Depends(get_current_user)):
    db = request.app.state.db
    await db.notifiche.update_one(
        {"_id": ObjectId(id)}, {"$addToSet": {"letta_da": str(user["_id"])}}
    )
    return JSONResponse({"ok": True}, headers={"HX-Trigger": "refresh-notifiche"})


# 🔹 Endpoint per il pallino rosso nel menu
@notifiche_router.get("/notifiche/count/{tipo}", response_class=HTMLResponse)
async def notifiche_count(
        tipo: str,
        request: Request,
        user = Depends(get_current_user)
):
    db = request.app.state.db
    q = {
        "tipo": tipo,
        "branch": {"$in": ["*", user["branch"]]},
        "letta_da": {"$ne": str(user["_id"])}
    }
    has_unread = await db.notifiche.count_documents(q)
    # se >0 restituisco il pallino rosso, altrimenti stringa vuota
    html = ('<span class="absolute -top-1 -right-2 '
            'inline-block w-2 h-2 rounded-full bg-red-600"></span>'
            if has_unread else '')
    return HTMLResponse(html)
