from fastapi import APIRouter, Request, Form, Depends
from fastapi.responses import RedirectResponse
from app.deps import require_admin, get_current_user               # updated import
from app.utils.save_with_notifica import save_and_notify

news_router = APIRouter(tags=["news"])

@news_router.post(
    "/news/new",
    status_code=303,
    response_class=RedirectResponse,
    dependencies=[Depends(require_admin)]
)
async def create_news(
    request: Request,
    title: str   = Form(...),
    content: str = Form(...),
    branch: str  = Form(...)
):
    await save_and_notify(
        request=request,
        collection="news",
        payload={"title": title.strip(),
                 "content": content.strip(),
                 "branch": branch.strip()},
        tipo="news",
        titolo=title.strip(),
        branch=branch.strip()
    )
    return RedirectResponse("/news", status_code=303)
