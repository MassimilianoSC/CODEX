from fastapi import APIRouter, Request, Form, Depends, HTTPException
from fastapi.responses import RedirectResponse, HTMLResponse
from app.deps import require_admin, get_current_user
from app.utils.save_with_notifica import save_and_notify
from app.models.contacts_model import ContactIn, ContactOut
from bson import ObjectId
from datetime import datetime

contatti_router = APIRouter(tags=["contatti"])

@contatti_router.post(
    "/contatti/new",
    status_code=303,
    response_class=RedirectResponse,
    dependencies=[Depends(require_admin)]
)
async def create_contact(
    request: Request,
    name: str = Form(...),
    role: str = Form(...),
    email: str = Form(...),
    phone: str = Form(None),
    branch: str = Form(...),
    hire_type: str = Form("*")
):
    hire_type_list = [hire_type] if isinstance(hire_type, str) else (hire_type or [])
    await save_and_notify(
        request=request,
        collection="contatti",
        payload={
            "name": name.strip(),
            "role": role.strip(),
            "email": email.strip().lower(),
            "phone": phone.strip() if phone else None,
            "branch": branch.strip(),
            "hire_type": hire_type_list
        },
        tipo="contatto",
        titolo=name.strip(),
        branch=branch.strip()
    )
    return RedirectResponse("/contatti", status_code=303)

@contatti_router.get("/contatti", response_class=HTMLResponse)
async def list_contacts(
    request: Request,
    user = Depends(get_current_user)
):
    db = request.app.state.db
    mongo_filter = {} if user["role"] == "admin" else {
        "$or": [
            {"hire_type": {"$exists": False}},
            {"hire_type": {"$size": 0}},
            {"hire_type": {"$in": [user["employment_type"]]}}
        ]
    }
    contacts = await db.contatti.find(mongo_filter).sort("created_at", -1).to_list(None)
    return request.app.state.templates.TemplateResponse(
        "contatti/contatti_index.html",
        {"request": request, "user": user, "contacts": contacts}
    )

@contatti_router.get(
    "/contatti/{contact_id}/edit",
    response_class=HTMLResponse,
    dependencies=[Depends(require_admin)]
)
async def edit_contact_form(
    request: Request,
    contact_id: str,
    user = Depends(get_current_user)
):
    db = request.app.state.db
    contact = await db.contatti.find_one({"_id": ObjectId(contact_id)})
    if not contact:
        raise HTTPException(404, "Contatto non trovato")
    return request.app.state.templates.TemplateResponse(
        "contatti/contatti_edit_partial.html",
        {"request": request, "c": contact, "user": user}
    )

@contatti_router.post(
    "/contatti/{contact_id}/edit",
    response_class=HTMLResponse,
    dependencies=[Depends(require_admin)]
)
async def edit_contact_submit(
    request: Request,
    contact_id: str,
    name: str = Form(...),
    role: str = Form(...),
    email: str = Form(...),
    phone: str = Form(None),
    branch: str = Form(...),
    hire_type: str = Form("*")
):
    db = request.app.state.db
    hire_type_list = [hire_type] if isinstance(hire_type, str) else (hire_type or [])
    await db.contatti.update_one(
        {"_id": ObjectId(contact_id)},
        {"$set": {
            "name": name.strip(),
            "role": role.strip(),
            "email": email.strip().lower(),
            "phone": phone.strip() if phone else None,
            "branch": branch.strip(),
            "hire_type": hire_type_list
        }}
    )
    updated = await db.contatti.find_one({"_id": ObjectId(contact_id)})
    resp = request.app.state.templates.TemplateResponse(
        "contatti/contatti_row_partial.html",
        {"request": request, "c": updated, "user": request.state.user}
    )
    resp.headers["HX-Trigger"] = "closeModal"
    return resp
