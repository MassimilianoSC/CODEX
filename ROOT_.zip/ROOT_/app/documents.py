from fastapi import APIRouter, Request, Form, Depends, HTTPException
from fastapi.responses import RedirectResponse, FileResponse, HTMLResponse
from app.deps import require_admin, get_current_user, get_docs_coll
from app.utils.save_with_notifica import save_and_notify
from bson import ObjectId
from datetime import datetime
from pathlib import Path
from motor.motor_asyncio import AsyncIOMotorCollection

# Costante per il percorso base dei documenti
BASE_DOCS_DIR = Path("media/docs")   # cartella radice documenti

def to_str_id(doc: dict) -> dict:
    """Converte l'_id Mongo in stringa per i template Jinja."""
    doc["_id"] = str(doc["_id"])
    if "uploaded_at" in doc and isinstance(doc["uploaded_at"], datetime):
        doc["uploaded_at"] = doc["uploaded_at"].date().isoformat()
    return doc

documents_router = APIRouter(tags=["documents"])

@documents_router.post(
    "/documents/new",
    status_code=303,
    response_class=RedirectResponse,
    dependencies=[Depends(require_admin)]
)
async def create_document(
    request: Request,
    filename: str = Form(...),
    path: str    = Form(...),
    branch: str  = Form(...),
    employment_type: str = Form(...),
    show_on_home: str = Form(None)
):
    db = request.app.state.db
    result = await save_and_notify(
        request=request,
        collection="documents",
        payload={
            "filename": filename,
            "path": path,
            "branch": branch.strip(),
            "employment_type": employment_type.strip()
        },
        tipo="documento",
        titolo=filename,
        branch=branch.strip()
    )
    # Recupera l'id del documento appena creato
    doc = await db.documents.find_one({"filename": filename, "path": path})
    if show_on_home:
        await db.home_highlights.update_one(
            {"type": "document", "object_id": doc["_id"]},
            {"$set": {
                "type": "document",
                "object_id": doc["_id"],
                "title": filename,
                "created_at": datetime.utcnow()
            }},
            upsert=True
        )
    else:
        await db.home_highlights.delete_one({"type": "document", "object_id": doc["_id"]})
    return RedirectResponse("/documents", status_code=303)

@documents_router.get(
    "/documents/{doc_id}/edit",
    response_class=HTMLResponse,
    dependencies=[Depends(require_admin)]
)
async def edit_document_form(
    request: Request,
    doc_id: str,
    user = Depends(get_current_user),
    docs_coll: AsyncIOMotorCollection = Depends(get_docs_coll)
):
    doc = await docs_coll.find_one({"_id": ObjectId(doc_id)})
    if not doc:
        raise HTTPException(404, "Documento non trovato")
    # Verifica se il documento è in evidenza
    db = request.app.state.db
    highlight = await db.home_highlights.find_one({"type": "document", "object_id": ObjectId(doc_id)})
    doc = to_str_id(doc)
    doc["show_on_home"] = bool(highlight)
    return request.app.state.templates.TemplateResponse(
        "documents/edit_partial.html",
        {"request": request, "d": doc, "user": user}
    )

@documents_router.post(
    "/documents/{doc_id}/edit",
    response_class=HTMLResponse,
    dependencies=[Depends(require_admin)]
)
async def edit_document_submit(
    request: Request,
    doc_id: str,
    title: str = Form(...),
    branch: str = Form(...),
    employment_type: str = Form(...),
    tags: str = Form(""),
    uploaded_at: str | None = Form(None),
    show_on_home: str = Form(None),
    user = Depends(get_current_user),
    docs_coll: AsyncIOMotorCollection = Depends(get_docs_coll)
):
    db = request.app.state.db
    update_doc = {
        "title": title.strip(),
        "branch": branch.strip(),
        "employment_type": employment_type.strip(),
        "tags": [t.strip() for t in tags.split(",") if t.strip()]
    }
    if uploaded_at:
        update_doc["uploaded_at"] = datetime.fromisoformat(uploaded_at)

    await docs_coll.update_one(
        {"_id": ObjectId(doc_id)},
        {"$set": update_doc}
    )

    # Gestione home_highlights
    if show_on_home:
        await db.home_highlights.update_one(
            {"type": "document", "object_id": ObjectId(doc_id)},
            {"$set": {
                "type": "document",
                "object_id": ObjectId(doc_id),
                "title": title.strip(),
                "created_at": datetime.utcnow()
            }},
            upsert=True
        )
    else:
        await db.home_highlights.delete_one({"type": "document", "object_id": ObjectId(doc_id)})

    new_doc = await docs_coll.find_one({"_id": ObjectId(doc_id)})
    resp = request.app.state.templates.TemplateResponse(
        "documents/row_partial.html",
        {"request": request, "d": to_str_id(new_doc), "user": user}
    )
    resp.headers["HX-Trigger"] = "closeModal"
    return resp
