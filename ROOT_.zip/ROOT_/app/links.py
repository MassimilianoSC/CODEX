from fastapi import APIRouter, Request, Form, Depends, HTTPException
from fastapi.responses import RedirectResponse, HTMLResponse
from app.deps import require_admin, get_current_user
from app.utils.save_with_notifica import save_and_notify
from app.models.links_model import LinkIn, LinkOut
from bson import ObjectId
from datetime import datetime

links_router = APIRouter(tags=["links"])

@links_router.post(
    "/links/new",
    status_code=303,
    response_class=RedirectResponse,
    dependencies=[Depends(require_admin)]
)
async def create_link(
    request: Request,
    title: str = Form(...),
    url: str = Form(...),
    description: str = Form(None),
    branch: str = Form(...),
    hire_type: str = Form("*")
):
    hire_type_list = [hire_type] if isinstance(hire_type, str) else (hire_type or [])
    await save_and_notify(
        request=request,
        collection="links",
        payload={
            "title": title.strip(),
            "url": url.strip(),
            "description": description.strip() if description else None,
            "branch": branch.strip(),
            "hire_type": hire_type_list
        },
        tipo="link",
        titolo=title.strip(),
        branch=branch.strip()
    )
    return RedirectResponse("/links", status_code=303)

@links_router.get("/links", response_class=HTMLResponse)
async def list_links(
    request: Request,
    user = Depends(get_current_user)
):
    db = request.app.state.db
    mongo_filter = {} if user["role"] == "admin" else {
        "$or": [
            {"hire_type": {"$exists": False}},
            {"hire_type": {"$size": 0}},
            {"hire_type": {"$in": [user["employment_type"]]}}
        ]
    }
    links = await db.links.find(mongo_filter).sort("created_at", -1).to_list(None)
    return request.app.state.templates.TemplateResponse(
        "links/links_index.html",
        {"request": request, "user": user, "links": links}
    )

@links_router.get(
    "/links/{link_id}/edit",
    response_class=HTMLResponse,
    dependencies=[Depends(require_admin)]
)
async def edit_link_form(
    request: Request,
    link_id: str,
    user = Depends(get_current_user)
):
    db = request.app.state.db
    link = await db.links.find_one({"_id": ObjectId(link_id)})
    if not link:
        raise HTTPException(404, "Link non trovato")
    return request.app.state.templates.TemplateResponse(
        "links/links_edit_partial.html",
        {"request": request, "l": link, "user": user}
    )

@links_router.post(
    "/links/{link_id}/edit",
    response_class=HTMLResponse,
    dependencies=[Depends(require_admin)]
)
async def edit_link_submit(
    request: Request,
    link_id: str,
    title: str = Form(...),
    url: str = Form(...),
    description: str = Form(None),
    branch: str = Form(...),
    hire_type: str = Form("*")
):
    db = request.app.state.db
    hire_type_list = [hire_type] if isinstance(hire_type, str) else (hire_type or [])
    await db.links.update_one(
        {"_id": ObjectId(link_id)},
        {"$set": {
            "title": title.strip(),
            "url": url.strip(),
            "description": description.strip() if description else None,
            "branch": branch.strip(),
            "hire_type": hire_type_list
        }}
    )
    updated = await db.links.find_one({"_id": ObjectId(link_id)})
    resp = request.app.state.templates.TemplateResponse(
        "links/links_row_partial.html",
        {"request": request, "l": updated, "user": request.state.user}
    )
    resp.headers["HX-Trigger"] = "closeModal"
    return resp
