// Modal functionality
document.addEventListener('DOMContentLoaded', () => {
  // Show modal when HTMX puts content in #modal-body
  document.body.addEventListener('htmx:afterSwap', e => {
    if (e.detail.target.id === 'modal-body') {
      document.getElementById('modal')?.classList.remove('hidden');
    }
  });

  // Hide modal when POST response triggers closeModal
  document.body.addEventListener('closeModal', () => {
    document.getElementById('modal')?.classList.add('hidden');
  });
});

/**
 * Shows a confirmation dialog; if user confirms,
 * triggers the "hxConfirm" event on the clicked button.
 */
export function showDelete(btn) {
  Swal.fire({
    title: 'Eliminare?',
    text: 'Questa azione è irreversibile',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#d33',
    cancelButtonColor: '#3085d6',
    confirmButtonText: 'Sì, elimina'
  }).then(result => {
    if (result.isConfirmed) {
      htmx.trigger(btn, 'hxConfirm'); // fake event → triggers DELETE
    }
  });
} 