from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse
from bson import ObjectId

from app.deps import require_admin
from app.deps import get_db
from app.templates import templates

router = APIRouter(prefix="/admin/shortcuts", tags=["admin"], dependencies=[Depends(require_admin)])

@router.get("/", response_class=HTMLResponse)
async def shortcuts_admin(request: Request, db=Depends(get_db)):
    shortcuts = await db.shortcuts.find().sort("order").to_list(length=None)
    return templates.TemplateResponse(
        "admin_shortcuts.html",
        {"request": request, "shortcuts": shortcuts},
    ) 