from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse
from app.templates import templates

router = APIRouter()

@router.get("/partials/shortcut_bar", response_class=HTMLResponse)
async def shortcut_bar_fragment(request: Request):
    db = request.app.state.db
    shortcuts = await db.shortcuts.find({"enabled": True}).sort("order").to_list(None)
    ctx = {"request": request, "shortcuts": shortcuts}
    response = templates.TemplateResponse("partials/shortcut_bar.html", ctx)
    response.headers["Cache-Control"] = "no-store"
    return response 