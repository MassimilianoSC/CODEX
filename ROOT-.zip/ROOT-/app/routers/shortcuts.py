from fastapi import APIRouter, Depends
from motor.motor_asyncio import AsyncIOMotorDatabase
from app.models.shortcut import Shortcut
from app.deps import get_db

router = APIRouter(prefix="/api/shortcuts", tags=["Shortcuts"])

@router.get("/", response_model=list[Shortcut])
async def get_enabled_shortcuts(db: AsyncIOMotorDatabase = Depends(get_db)):
    docs = db.shortcuts.find({"enabled": True}).sort("order")
    return [Shortcut(**{**d, "_id": str(d["_id"])}) async for d in docs] 