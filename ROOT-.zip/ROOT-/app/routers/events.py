from fastapi import APIRouter
from fastapi.responses import StreamingResponse
from app.sse.broker import broker
import asyncio

router = APIRouter()

@router.get("/events")
async def sse_endpoint():
    queue = await broker.connect()

    async def event_generator():
        try:
            while True:
                data = await queue.get()
                yield f"event: {data}\ndata: ok\n\n"
        except asyncio.CancelledError:
            pass  # client disconnected

    return StreamingResponse(event_generator(), media_type="text/event-stream") 