from bson import ObjectId
from pydantic_core import core_schema
from pydantic import GetCoreSchemaHandler

class PyObjectId(ObjectId):
    """ObjectId compatibile con Pydantic v1 e v2."""

    # — v2 ---------------------------------------------------------
    @classmethod
    def __get_pydantic_core_schema__(
        cls, _source_type: type, _handler: GetCoreSchemaHandler
    ) -> core_schema.CoreSchema:
        return core_schema.with_info_after_validator_function(
            cls.validate,
            core_schema.str_schema(),
        )

    # — v1 (fallback) ---------------------------------------------
    @classmethod
    def __get_validators__(cls):
        yield cls.validate

    # comune
    @classmethod
    def validate(cls, v, _info=None):
        if isinstance(v, ObjectId):
            return cls(str(v))
        if ObjectId.is_valid(v):
            return cls(v)
        raise ValueError("Invalid ObjectId") 