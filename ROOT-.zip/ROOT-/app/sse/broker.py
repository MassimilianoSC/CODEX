import asyncio

class EventBroker:
    def __init__(self):
        self.connections: list[asyncio.Queue[str]] = []

    async def push(self, msg: str):
        for q in list(self.connections):
            await q.put(msg)

    async def connect(self) -> asyncio.Queue[str]:
        q: asyncio.Queue[str] = asyncio.Queue()
        self.connections.append(q)
        return q

broker = EventBroker() 