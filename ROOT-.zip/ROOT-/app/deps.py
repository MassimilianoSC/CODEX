from fastapi import Request, Depends, HTTPException, Response
from bson import ObjectId
from fastapi.responses import RedirectResponse
from motor.motor_asyncio import AsyncIOMotorCollection, AsyncIOMotorDatabase
from pymongo.read_preferences import ReadPreference
from typing import Optional

def get_nav_items():
    """Returns the list of navigation items for the main menu."""
    return [
        {"href": "/me",         "label": "Profilo"},
        {"href": "/documents",  "label": "Documenti"},
        {"href": "/links",      "label": "Link utili"},
        {"href": "/news",       "label": "News"},
        {"href": "/contatti",   "label": "Contatti"},
        {"href": "https://hqe.it", "label": "Sito HQE", "external": True},
    ]

def _get_user_from_request(request: Request) -> Optional[object]:
    """
    Tenta di recuperare l'utente autenticato senza sollevare eccezioni.
    1) da request.scope["user"]   (standard starlette auth)
    2) da request.state.user      (se un tuo middleware lo imposta lì)
    3) altrimenti None
    """
    user = request.scope.get("user")          # NON usa request.user ✅
    if user is None:
        user = getattr(request.state, "user", None)
    return user

def build_nav_items(user: Optional[object] = None) -> list[dict]:
    """Elenco voci di menu, con 'Utenti' e 'Scorciatoie' solo per admin."""
    is_admin = (
        (isinstance(user, dict) and user.get("role") == "admin") or
        getattr(user, "role", None) == "admin"
    )

    items = [
        {"href": "/",            "label": "Home"},
        {"href": "/me",          "label": "Profilo"},
        {"href": "/documents",   "label": "Documenti"},
        {"href": "/links",       "label": "Link utili"},
        {"href": "/news",        "label": "News"},
        {"href": "/contatti",    "label": "Contatti"},
        {"href": "https://hqe.it", "label": "Sito HQE", "external": True},
        {"href": "/me/password", "label": "Cambia password"},
        {"href": "/logout",      "label": "Logout"},
    ]

    if is_admin:
        # inserisci "Utenti" subito prima di Cambia PW / Logout
        items.insert(-2, {"href": "/users", "label": "Utenti"})
        # aggiungi "Scorciatoie" subito prima di Cambia PW / Logout
        items.insert(-2, {"href": "/admin/shortcuts/", "label": "Scorciatoie"})

    return items

async def nav_ctx(request: Request):
    """Dipendenza che fornisce nav_items *e* shortcuts a tutti i template."""
    user   = _get_user_from_request(request)
    shortcuts = getattr(request.state, "shortcuts", [])
    print("DEBUG shortcuts →", len(shortcuts))
    return {
        "nav_items": build_nav_items(user),
        "shortcuts": shortcuts
    }

# ─── FUNZIONE ORA INDIPENDENTE ─────────────────────────────
async def get_current_user(request: Request):
    """
    Restituisce l'utente autenticato oppure:
    • 401 + HX-Redirect  se la chiamata arriva da HTMX
    • 302/303            se è una navigazione "normale" del browser
    """
    uid = request.session.get("user_id")

    # ─── NIENTE SESSIONE ────────────────────────────────────────────
    if not uid:
        if "HX-Request" in request.headers:
            # 1) HTMX capisce HX-Redirect e ricarica la pagina
            raise HTTPException(
                status_code=401,
                headers={"HX-Redirect": "/login"}
            )
        # 2) Navigazione classica: 401 con HX-Redirect
        raise HTTPException(
            status_code=401,
            headers={"HX-Redirect": "/login"}
        )

    # ─── LOOK-UP DELL'UTENTE ────────────────────────────────────────
    user = await request.app.state.db.users.find_one({"_id": ObjectId(uid)})
    if not user:
        raise HTTPException(401, "User not found")

    # ─── OBBLIGO CAMBIO PASSWORD ───────────────────────────────────
    if user.get("must_change_pw") and request.url.path not in ("/me/password", "/logout"):
        # Se è una richiesta alle notifiche, restituisci 204 No Content
        if request.url.path.startswith("/notifiche/"):
            return Response(status_code=204)
            
        target = "/me/password?first=1"
        if "HX-Request" in request.headers:
            raise HTTPException(401, headers={"HX-Redirect": target})
        raise HTTPException(401, headers={"HX-Redirect": target})

    # tutto ok → salva l'utente nello state e restituiscilo
    request.state.user = user
    return user

async def require_admin(
    _: Request,
    user = Depends(get_current_user)
):
    if user["role"] != "admin":
        raise HTTPException(status_code=403, detail="Admin only")
    return True

async def get_db(request: Request) -> AsyncIOMotorDatabase:
    """Database MongoDB"""
    return request.app.state.db

async def get_docs_coll(
    user = Depends(get_current_user),
    db = Depends(get_db)
) -> AsyncIOMotorCollection:
    """Collection documenti branch-aware"""
    if user["role"] == "admin":
        return db.documents
    return db.documents.with_options(
        read_preference=ReadPreference.SECONDARY
    ).find({"branch": user["branch"]}) 