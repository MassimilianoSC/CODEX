from app.utils.pydantic_objectid import PyObjectId
from pydantic import BaseModel, Field
from typing import Literal, Optional

class Shortcut(BaseModel):
    id: PyObjectId | None = Field(default=None, alias="_id")

    code: str
    label: str
    icon: str
    type: Literal["route", "url", "doc", "contact"]
    target: str
    order: int
    enabled: bool = True

    model_config = {
        "populate_by_name": True,        # _id <-> id
        "arbitrary_types_allowed": True,
        "json_encoders": {PyObjectId: str},
    }

class ShortcutUpdate(BaseModel):
    order:   Optional[int]  = Field(None, ge=0)
    enabled: Optional[bool] = None 