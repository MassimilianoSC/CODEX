from typing import List, Optional
from pydantic import BaseModel, Field
from datetime import datetime
from app.utils.pydantic_objectid import PyObjectId

class DocumentIn(BaseModel):
    """Input model for document creation/update."""
    filename: str
    path: str
    branch: str
    employment_type: str
    tags: Optional[List[str]] = Field(default_factory=list)
    uploaded_at: Optional[datetime] = None
    created_at: Optional[datetime] = None

class DocumentOut(DocumentIn):
    """Output model for document retrieval."""
    id: PyObjectId | None = Field(default=None, alias="_id")

    model_config = {
        "populate_by_name": True,        # _id <-> id
        "arbitrary_types_allowed": True,
        "json_encoders": {PyObjectId: str},
    } 