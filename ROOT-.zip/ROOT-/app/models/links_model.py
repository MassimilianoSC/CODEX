from typing import List, Optional
from pydantic import BaseModel, Field
from datetime import datetime
from app.utils.pydantic_objectid import PyObjectId

class LinkIn(BaseModel):
    title: str
    url: str
    description: Optional[str] = None
    branch: Optional[List[str]] = Field(default_factory=list)
    hire_type: Optional[List[str]] = Field(default_factory=list)
    created_at: Optional[datetime] = None
    featured: bool = False

class LinkOut(LinkIn):
    id: PyObjectId | None = Field(default=None, alias="_id")

    model_config = {
        "populate_by_name": True,        # _id <-> id
        "arbitrary_types_allowed": True,
        "json_encoders": {PyObjectId: str},
    } 