from typing import List, Optional
from pydantic import BaseModel, Field
from datetime import datetime
from app.utils.pydantic_objectid import PyObjectId

class ContactIn(BaseModel):
    name: str
    role: str
    email: str
    phone: Optional[str] = None
    branch: Optional[List[str]] = Field(default_factory=list)
    hire_type: Optional[List[str]] = Field(default_factory=list)
    created_at: Optional[datetime] = None

class ContactOut(ContactIn):
    id: PyObjectId | None = Field(default=None, alias="_id")

    model_config = {
        "populate_by_name": True,        # _id <-> id
        "arbitrary_types_allowed": True,
        "json_encoders": {PyObjectId: str},
    } 