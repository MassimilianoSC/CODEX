from fastapi import APIRouter, Depends, HTTPException, Request
from motor.motor_asyncio import AsyncIOMotorDatabase
from bson import ObjectId
from fastapi.responses import HTMLResponse

from app.deps import get_db
from app.models.shortcut import Shortcut, ShortcutUpdate
from app.templates import templates
from app.sse.broker import broker

router = APIRouter(
    prefix="/api/shortcuts",
    tags=["Shortcuts"],
)

@router.get("/", response_model=list[Shortcut])
async def get_enabled_shortcuts(db: AsyncIOMotorDatabase = Depends(get_db)):
    docs = await db.shortcuts.find({"enabled": True}).sort("order").to_list(None)
    return docs

@router.patch("/{id}", response_model=Shortcut)
async def patch_shortcut(
    id: str,
    data: ShortcutUpdate,
    db: AsyncIOMotorDatabase = Depends(get_db),
):
    update = {k: v for k, v in data.dict(exclude_unset=True).items()}
    if not update:
        raise HTTPException(status_code=400, detail="Empty update payload")

    result = await db.shortcuts.update_one(
        {"_id": ObjectId(id)},
        {"$set": update},
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Shortcut not found")

    doc = await db.shortcuts.find_one({"_id": ObjectId(id)})
    if doc and "_id" in doc:
        doc["_id"] = str(doc["_id"])
    await broker.push("shortcut_updated")
    return Shortcut(**doc)

@router.get("/", response_class=HTMLResponse)
async def get_shortcut_bar(request: Request, db: AsyncIOMotorDatabase = Depends(get_db)):
    shortcuts = await db.shortcuts.find({"enabled": True}).sort("order").to_list(None)
    return templates.TemplateResponse(
        "partials/shortcut_bar.html",
        {"request": request, "shortcuts": shortcuts}
    ) 