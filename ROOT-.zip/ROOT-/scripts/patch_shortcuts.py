import asyncio, motor.motor_asyncio as ami

async def patch():
    client = ami.AsyncIOMotorClient("mongodb://localhost")
    db = client["intranet"]
    res = await db.shortcuts.update_many({}, {"$set": {"enabled": True}})
    print("Aggiornati", res.modified_count, "documenti")

if __name__ == "__main__":
    asyncio.run(patch()) 