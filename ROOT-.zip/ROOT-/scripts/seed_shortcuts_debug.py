import asyncio, os, pprint
import motor.motor_asyncio as ami
from bson import ObjectId

DB_NAME = os.getenv("MONGO_DB", "intranet")       # ← default intranet
print("DB di destinazione  ➜", DB_NAME)

defaults = [
    {"code": "home",      "label": "Home",      "icon": "home",      "type": "route", "target": "/",          "order": 0},
    {"code": "news",      "label": "News",      "icon": "newspaper", "type": "route", "target": "/news",      "order": 1},
    {"code": "docs",      "label": "Documenti", "icon": "folder",    "type": "route", "target": "/documents", "order": 2},
    {"code": "directory", "label": "Directory", "icon": "users",     "type": "route", "target": "/directory", "order": 3},
    {"code": "tasks",     "label": "Tasks",     "icon": "checklist", "type": "route", "target": "/tasks",     "order": 4},
]

async def main():
    client = ami.AsyncIOMotorClient("mongodb://localhost")
    db = client[DB_NAME]

    # pulisco e inserisco
    await db.shortcuts.drop()
    docs = [{**d, "_id": ObjectId()} for d in defaults]
    result = await db.shortcuts.insert_many(docs)
    print("Inseriti ID:", result.inserted_ids)

    # leggo subito per conferma
    stored = await db.shortcuts.find().to_list(length=None)
    print("Ora nella collezione ci sono", len(stored), "documenti:")
    pprint.pp(stored)

asyncio.run(main()) 