import sys, pathlib; sys.path.append(str(pathlib.Path(__file__).resolve().parents[1]))

import asyncio, motor.motor_asyncio as aiomotor
from bson import ObjectId
from app.models.shortcut import Shortcut

defaults = [
    {"code": "home",      "label": "Home",      "icon": "home",      "type": "route", "target": "/",            "order": 0, "enabled": True},
    {"code": "news",      "label": "News",      "icon": "newspaper", "type": "route", "target": "/news",        "order": 1, "enabled": True},
    {"code": "docs",      "label": "Documenti", "icon": "folder",    "type": "route", "target": "/documents",   "order": 2, "enabled": True},
    {"code": "directory", "label": "Directory", "icon": "users",     "type": "route", "target": "/directory",   "order": 3, "enabled": True},
    {"code": "tasks",     "label": "Tasks",     "icon": "checklist", "type": "route", "target": "/tasks",       "order": 4, "enabled": True},
]

async def main():
    db = aiomotor.AsyncIOMotorClient("mongodb://localhost")["intranet"]

    # 1) svuota la collection
    await db.shortcuts.delete_many({})

    # 2) prepara i documenti **senza** _id quando None
    docs = []
    for d in defaults:
        s = Shortcut(**d)
        doc = s.dict(by_alias=True, exclude_none=True)   # rimuove _id=None
        docs.append(doc)

    # 3) inserisci la lista
    await db.shortcuts.insert_many(docs)
    print("✅  Shortcuts seeded.")

if __name__ == "__main__":
    asyncio.run(main()) 