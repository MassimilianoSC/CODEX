DEFAULT_BRANCHES = ["HQE", "HQ ITALIA", "HQIA"]

DEFAULT_HIRE_TYPES = [
    {"id": "TD", "label": "Tempo Determinato"},
    {"id": "TI", "label": "Tempo Indeterminato"},
    {"id": "AP", "label": "Apprendistato"},
    {"id": "CO", "label": "Collaborazione"},
] 