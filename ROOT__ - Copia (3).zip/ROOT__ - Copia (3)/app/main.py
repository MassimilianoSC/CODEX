  "type": "contact",
  "title": contact["name"],
  "branch": contact["branch"],
  "role": contact.get("role", ""),  # stringa vuota se manca
  "hire_type": contact.get("hire_type", []), 