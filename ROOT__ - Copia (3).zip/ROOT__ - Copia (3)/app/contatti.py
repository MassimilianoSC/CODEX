from fastapi import APIRouter, Request, Form, Depends, HTTPException
from fastapi.responses import RedirectResponse, HTMLResponse, PlainTextResponse
from app.deps import require_admin, get_current_user
from app.utils.save_with_notifica import save_and_notify
from app.models.contacts_model import ContactIn, ContactOut
from bson import ObjectId
from datetime import datetime
from app.constants import DEFAULT_BRANCHES, DEFAULT_HIRE_TYPES
from typing import Annotated

contatti_router = APIRouter(tags=["contatti"])

@contatti_router.post(
    "/contatti/new",
    status_code=303,
    response_class=RedirectResponse,
    dependencies=[Depends(require_admin)]
)
async def create_contact(
    request: Request,
    name: str = Form(...),
    email: str = Form(...),
    phone: str = Form(None),
    bu: str = Form(None),
    team: str = Form(None),
    branch: str = Form(...),
    hire_type: str = Form(...),
    show_on_home: Annotated[bool, Form()] = False,
    current_user: dict = Depends(require_admin)
):
    db = request.app.state.db
    await db.contatti.insert_one({
        "name": name.strip(),
        "email": email.strip(),
        "phone": (phone or "").strip(),
        "bu": (bu or "").strip() or None,
        "team": (team or "").strip() or None,
        "branch": branch,
        "hire_type": hire_type,
        "show_on_home": bool(show_on_home),
        "created_at": datetime.utcnow()
    })
    return RedirectResponse("/contatti", status_code=303)

@contatti_router.get("/contatti", response_class=HTMLResponse)
async def list_contacts(
    request: Request,
    current_user = Depends(get_current_user)
):
    db = request.app.state.db
    mongo_filter = {} if current_user["role"] == "admin" else {
        "$or": [
            {"hire_type": {"$exists": False}},
            {"hire_type": {"$size": 0}},
            {"hire_type": {"$in": [current_user["employment_type"]]}}
        ]
    }
    contacts = await db.contatti.find(mongo_filter).sort("created_at", -1).to_list(None)
    return request.app.state.templates.TemplateResponse(
        "contatti/contatti_index.html",
        {
            "request": request,
            "contacts": contacts,
            "current_user": current_user
        }
    )

@contatti_router.get(
    "/contatti/{contact_id}/edit",
    response_class=HTMLResponse,
    dependencies=[Depends(require_admin)]
)
async def edit_contact_form(
    request: Request,
    contact_id: str,
    user = Depends(get_current_user)
):
    db = request.app.state.db
    contact = await db.contatti.find_one({"_id": ObjectId(contact_id)})
    if not contact:
        raise HTTPException(404, "Contatto non trovato")
    
    branches = await db.branches.distinct("name")
    if not branches:
        branches = DEFAULT_BRANCHES
    
    hire_types = await db.hire_types.find().to_list(None)
    if not hire_types:
        hire_types = DEFAULT_HIRE_TYPES
    
    return request.app.state.templates.TemplateResponse(
        "contatti/contatti_edit_partial.html",
        {
            "request": request,
            "c": contact,
            "user": user,
            "branches": branches,
            "hire_types": hire_types
        }
    )

@contatti_router.post(
    "/contatti/{contact_id}/edit",
    response_class=HTMLResponse,
    dependencies=[Depends(require_admin)]
)
async def edit_contact_submit(
    request: Request,
    contact_id: str,
    name: str = Form(...),
    email: str = Form(...),
    phone: str = Form(...),
    branch: str = Form(...),
    hire_type: str = Form("*"),
    bu: str = Form(None),
    team: str = Form(None),
    show_on_home: str = Form(None)
):
    db = request.app.state.db
    hire_type_list = [hire_type] if isinstance(hire_type, str) else (hire_type or [])
    await db.contatti.update_one(
        {"_id": ObjectId(contact_id)},
        {"$set": {
            "name": name.strip(),
            "email": email.strip(),
            "phone": phone.strip(),
            "branch": branch.strip(),
            "hire_type": hire_type_list,
            "bu": bu.strip() if bu else None,
            "team": team.strip() if team else None
        }}
    )

    # Gestione home_highlights
    if show_on_home:
        await db.home_highlights.update_one(
            {"type": "contact", "object_id": ObjectId(contact_id)},
            {"$set": {
                "type": "contact",
                "object_id": ObjectId(contact_id),
                "title": name.strip(),
                "created_at": datetime.utcnow(),
                "branch": branch.strip(),
                "hire_type": hire_type_list
            }},
            upsert=True
        )
    else:
        await db.home_highlights.delete_one({"type": "contact", "object_id": ObjectId(contact_id)})

    updated = await db.contatti.find_one({"_id": ObjectId(contact_id)})
    resp = request.app.state.templates.TemplateResponse(
        "contatti/contatti_row_partial.html",
        {"request": request, "c": updated, "user": request.state.user}
    )
    resp.headers["HX-Trigger"] = "closeModal"
    return resp

@contatti_router.get("/contatti/new", response_class=HTMLResponse)
async def new_contact(request: Request, current_user: dict = Depends(require_admin)):
    db = request.app.state.db
    branches = await db.branches.distinct("name")
    if not branches:
        branches = DEFAULT_BRANCHES

    hire_types = await db.hire_types.find().to_list(None)
    if not hire_types:
        hire_types = DEFAULT_HIRE_TYPES

    print("branches:", branches)        # debug: lista filiali
    print("hire_types:", hire_types)    # debug: lista tipologie assunzione
    
    return request.app.state.templates.TemplateResponse(
        "contatti/contatti_new.html",
        {
            "request": request,
            "branches": branches,
            "hire_types": hire_types
        }
    )

@contatti_router.get("/contatti/new/partial", response_class=HTMLResponse)
async def new_contact_partial(request: Request, current_user: dict = Depends(require_admin)):
    db = request.app.state.db
    branches = await db.branches.distinct("name")
    if not branches:
        branches = DEFAULT_BRANCHES

    hire_types = await db.hire_types.find().to_list(None)
    if not hire_types:
        hire_types = DEFAULT_HIRE_TYPES

    print("branches (partial):", branches)        # debug: lista filiali
    print("hire_types (partial):", hire_types)    # debug: lista tipologie assunzione
    
    return request.app.state.templates.TemplateResponse(
        "contatti/contatto_new_partial.html",
        {
            "request": request,
            "branches": branches,
            "hire_types": hire_types
        }
    )

@contatti_router.put("/contatti/{contact_id}", status_code=200)
async def update_contact(
    request: Request,
    contact_id: str,
    name: str = Form(...),
    email: str = Form(...),
    phone: str = Form(None),
    bu: str = Form(None),
    team: str = Form(None),
    branch: str = Form(...),
    hire_type: str = Form(...),
    show_on_home: Annotated[bool, Form()] = False,
    current_user: dict = Depends(get_current_user)
):
    db = request.app.state.db
    await db.contatti.update_one(
        {"_id": ObjectId(contact_id)},
        {"$set": {
            "name": name.strip(),
            "email": email.strip(),
            "phone": (phone or "").strip(),
            "bu": (bu or "").strip() or None,
            "team": (team or "").strip() or None,
            "branch": branch,
            "hire_type": hire_type,
            "show_on_home": bool(show_on_home),
            "updated_at": datetime.utcnow(),
        }}
    )
    c = await db.contatti.find_one({"_id": ObjectId(contact_id)})
    html = request.app.state.templates.TemplateResponse(
        "contatti/contatti_row_partial.html",
        {"request": request, "c": c, "user": current_user},
        status_code=200
    )
    html.headers["HX-Trigger"] = "closeModal"
    return html
