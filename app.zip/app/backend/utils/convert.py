import re

# Mappatura speciale per casi particolari
_SPECIAL = {
    "SitoRifAlfa24": "sito_rif_alfa_24",
}

def camel_to_snake(name: str) -> str:
    """Converti un nome in formato CamelCase in snake_case."""
    if name in _SPECIAL:
        return _SPECIAL[name]
    
    # Inserisci un underscore prima di ogni lettera maiuscola
    # e converti tutto in minuscolo
    s1 = re.sub('(.)([A-Z][a-z]+)', r'\1_\2', name)
    return re.sub('([a-z0-9])([A-Z])', r'\1_\2', s1).lower() 