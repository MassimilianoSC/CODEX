"""
XML Parser utility per PraticaImpiantoCEMRL usando xmlschema.
Gestisce caricamento, validazione e salvataggio degli XML.
"""

from __future__ import annotations
import logging
from pathlib import Path
from typing import Union, Any, Dict, List
from io import StringIO
from xml.etree import ElementTree as ET

import xmlschema
from lxml import etree

from .fixer_order import ordered, dict_snake_to_camel
from app.backend.models.pratica_model import PraticaImpiantoCEMRL

logger = logging.getLogger(__name__)

# Percorso XSD rispetto a questo file
XSD_PATH = Path(__file__).parent.parent / "schema" / "schemas" / "PraticaImpiantoCEMRL_v01.10.xsd"

# Schema singleton
_SCHEMA = xmlschema.XMLSchema(str(XSD_PATH))

# Set of top-level keys that should remain in their original case
TOP_LEVEL_KEYS = {
    "TipoPratica",
    "NotePratica",
    "Impianto",          # Aggiunto per preservare il tag radice
    "Sistema",           # Aggiunto per prevenire altri casi simili
    "PuntoMisura",       # Aggiunto per prevenire altri casi simili
    "Misura",            # Aggiunto per prevenire altri casi simili
    "CRELProgettoSRB",   # Aggiunto per prevenire altri casi simili
    "FileMsi"            # Aggiunto per prevenire altri casi simili
}

def _preserve_top_level_keys(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Preserves top-level keys in their original form while converting nested keys to snake_case.
    """
    result = {}
    # calcola l'insieme lowercase UNA VOLTA sola
    _lower_set = {k.lower() for k in TOP_LEVEL_KEYS}

    for key, value in data.items():
        if key.lower() in _lower_set:
            # ➜ mantieni la chiave così com'è – NON convertirla più
            result[key] = value
        else:
            result[key.lower()] = value       # converti solo i non-top
    return result

def load(xml_path: Union[str, Path]) -> PraticaImpiantoCEMRL:
    """
    Carica un file XML, lo validа (in lax mode) e ritorna il modello PraticaImpiantoCEMRL.
    """
    xml_path = Path(xml_path)
    if not xml_path.exists():
        raise FileNotFoundError(f"XML file not found: {xml_path}")

    # ------------------------------------------------------------------ 
    # Validazione super-leggera: ci fermiamo al 1° errore. 
    try: 
        next(_SCHEMA.iter_errors(str(xml_path)))     # Stop al primo 
        logger.warning("XML non conforme allo schema - carico comunque") 
    except StopIteration: 
        pass     # File valido: nessun warning 
    except Exception as exc: 
        logger.warning("Quick XSD check fallito: %s", exc)   # prudenziale 
    # ------------------------------------------------------------------

    # trasforma direttamente in dict secondo lo XSD
    tree = etree.parse(str(xml_path))
    data = _SCHEMA.to_dict(tree)

    # --- MODELLI ANTENNA ------------------------------------------------
    xml_node = tree.getroot()
    cod_mod = xml_node.findtext('.//ModelloAntenna/CodiceModelloAntenna')
    if cod_mod:
        data.setdefault('modello_antenna_list', [{}])[0]['codice_modello_antenna'] = cod_mod

    # --- FILE MSI -------------------------------------------------------
    msi = xml_node.find('.//FileMsi')
    if msi is not None:
        data.setdefault('file_msi_list', [{}])[0].update({
            'nome_file_msi': msi.findtext('NomeFileMsi', ''),
            'grado_tilte'  : msi.findtext('GradoTilte',  ''),
        })

    print("DEBUG root keys BEFORE filter:", list(data.keys()))
    data = _preserve_top_level_keys(data)
    print("DEBUG root keys AFTER  filter:", list(data.keys()))
    
    logger.debug("Dopo xmlschema.to_dict(): %s", list(data.keys()))
    
    # costruisci il dataclass
    model = PraticaImpiantoCEMRL.from_dict(data)
    return model


def save(pratica: PraticaImpiantoCEMRL, xml_path: str | None) -> str:
    """
    Serializza il modello PraticaImpiantoCEMRL in XML.
    Se xml_path è None, restituisce solo la stringa XML.
    Altrimenti salva anche su disco e restituisce la stringa.
    """
    # Prepara il dict in CamelCase
    model_dict = dict_snake_to_camel(pratica.to_dict())
    model_dict = ordered(model_dict, "PraticaImpiantoCEMRLType")

    # Crea il root element via schema.encode()
    schema = _SCHEMA  # già caricato
    result = schema.encode(
        model_dict,
        path="/PraticaImpiantoCEMRL",
        validation="lax"
    )
    root_elem = result[0] if isinstance(result, tuple) else result

    xsi_attr = "{http://www.w3.org/2001/XMLSchema-instance}noNamespaceSchemaLocation"
    if xsi_attr not in root_elem.attrib:
        root_elem.set(xsi_attr, "PraticaImpiantoCEMRL_v01.10.xsd")

    # Serializza in stringa
    xml_str = xmlschema.etree_tostring(
        root_elem,
        xml_declaration=True,
        encoding="unicode"
    )

    # Se richiesto, salva anche su disco
    if xml_path:
        Path(xml_path).write_text(xml_str, encoding="utf-8")

    return xml_str


def validate_xml(xml_path: Union[str, Path]) -> List[str]:
    """
    Restituisce la lista di errori di validazione per un dato XML.
    """
    xml_path = Path(xml_path)
    if not xml_path.exists():
        return [f"XML not found: {xml_path}"]
    return [err.reason for err in _SCHEMA.iter_errors(str(xml_path))]


def to_string(pratica_dict: dict) -> str:
    """
    Restituisce l'XML come stringa senza salvare su disco.
    Accetta il dict già pronto (quello che hai in build_xml_from_form).
    """
    # Prepara il dict in CamelCase
    model_dict = dict_snake_to_camel(pratica_dict)
    model_dict = ordered(model_dict, "PraticaImpiantoCEMRLType")

    # Crea il root element via schema.encode()
    schema = _SCHEMA  # già caricato
    result = schema.encode(
        model_dict,
        path="/PraticaImpiantoCEMRL",
        validation="lax"
    )
    root_elem = result[0] if isinstance(result, tuple) else result

    xsi_attr = "{http://www.w3.org/2001/XMLSchema-instance}noNamespaceSchemaLocation"
    if xsi_attr not in root_elem.attrib:
        root_elem.set(xsi_attr, "PraticaImpiantoCEMRL_v01.10.xsd")

    # Serializza in stringa
    return xmlschema.etree_tostring(
        root_elem,
        xml_declaration=True,
        encoding="unicode"
    )


def save_dict(data: dict) -> str:
    """
    Serializza un dizionario in XML string.
    Converte prima in PraticaImpiantoCEMRL per assicurare la validità.
    """
    pratica = PraticaImpiantoCEMRL.from_dict(data)
    return save(pratica, None)
