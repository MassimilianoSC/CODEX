﻿from dataclasses import fields, is_dataclass
from typing import Type, Any, get_origin, get_args
from wtforms import Form, Field, FormField, FieldList, SelectField
from wtforms.validators import DataRequired, Optional as OptionalValidator
from wtforms import (
    StringField, IntegerField, DecimalField, BooleanField,
)
from decimal import Decimal
from enum import IntEnum, StrEnum

# Mappatura tipi dataclass → WTForms Field
_DATACLASS_TO_WTF: dict[Any, Any] = {
    int: IntegerField,
    float: DecimalField,
    str: StringField,
    bool: BooleanField,
    Decimal: DecimalField,  # aggiunta per decimal.Decimal
}

def _make_field(label: str, typ, required: bool) -> Field:
    """
    Crea l'istanza WTForms appropriata per il tipo Python dato.
    Supporta tipi base, enum e liste annidate.
    """
    validators = [DataRequired()] if required else [OptionalValidator()]

    # Gestione Enum
    if hasattr(typ, "__members__"):
        # Differenzia IntEnum e StrEnum per il coerce corretto
        coerce = int if issubclass(typ, IntEnum) else str
        return SelectField(
            label,
            choices=[(e.value, e.name) for e in typ],
            coerce=coerce,
            validators=validators
        )

    # Gestione Liste
    if get_origin(typ) is list:
        inner_type = get_args(typ)[0]
        if is_dataclass(inner_type):
            return FieldList(
                FormField(dataclass_to_form(inner_type)),
                min_entries=0,
                label=label
            )

    # Tipi base
    wtfield_cls = _DATACLASS_TO_WTF.get(typ, StringField)
    return wtfield_cls(label=label, validators=validators)

def dataclass_to_form(dc_cls: Type[Any]) -> Type[Form]:
    """
    Genera una classe WTForms.Form a partire da una dataclass.
    Supporta:
    - Tipi base (str, int, float, bool)
    - Enum (→ SelectField)
    - Liste di dataclass (→ FieldList di FormField)
    - Metadata 'required' per validazione
    """
    if not is_dataclass(dc_cls):
        raise TypeError(f"{dc_cls} non è un dataclass")

    attrs: dict[str, Any] = {}
    for f in fields(dc_cls):
        # Determina il tipo base (per gestire Optional[...] etc.)
        typ = f.type
        origin = get_origin(typ)
        if origin is not None:
            args = get_args(typ)
            typ = args[0] if args else typ

        # usa metadata['label'] se presente, altrimenti genera from snake_case
        label = f.metadata.get(
            'label',
            f.name.replace('_', ' ').capitalize()
        )
        attrs[f.name] = _make_field(
            label=label,
            typ=typ,
            required=f.metadata.get('required', False)
        )

    # Rinomina la classe Form
    form_name = dc_cls.__name__ + "Form"
    return type(form_name, (Form,), attrs)
