"""
– se lanciato come script, rigenera order_map.json  
– se importato, espone la funzione `ordered` per ordinare i dict
"""
from __future__ import annotations
import json, pathlib, sys
from collections import OrderedDict
import re
from typing import Any

ORDER_FILE = pathlib.Path(__file__).with_name("order_map.json")

# ----------------------------------------------------------------------
# ✨ 1.  FUNZIONE USATA A RUN-TIME  ✨
# ----------------------------------------------------------------------
# carica la mappa (una sola volta)
try:
    _ORDER_MAP: dict[str, list[str]] = json.loads(ORDER_FILE.read_text(encoding="utf-8"))
except FileNotFoundError:
    _ORDER_MAP = {}

def ordered(data: dict, typename: str) -> dict:
    """
    Ritorna un nuovo dict con le chiavi nell’ordine richiesto dallo XSD.
    Se `typename` non è presente in _ORDER_MAP, restituisce il dict invariato.
    Gestisce in modo ricorsivo i sotto-diz. e mantiene eventuali chiavi extra.
    """
    seq = _ORDER_MAP.get(typename)
    if not seq:                       # nessuna regola → niente da fare
        return data

    out: OrderedDict[str, object] = OrderedDict()
    for key in seq:
        if key not in data:
            continue
        val = data[key]
        # prova a riordinare anche i sotto-elementi (solo se dict)
        if isinstance(val, dict):
            # per semplicità assumiamo che il nome del tipo coincida con la chiave
            val = ordered(val, key + "Type")
        elif isinstance(val, list):
            # riordina ogni dict dentro una lista
            val = [ordered(v, key + "Type") if isinstance(v, dict) else v for v in val]
        out[key] = val

    # append eventuali chiavi non previste
    for k, v in data.items():
        if k not in out:
            out[k] = v
    return out
# ----------------------------------------------------------------------
# ✨ 2.  PARTE “CLI”  ✨  (rigenera order_map.json se eseguito come script)
# ----------------------------------------------------------------------
def _dump_order_map():
    """rileggi XSD e rigenera order_map.json (come faceva il vecchio script)"""
    import xmlschema, re
    XSD = pathlib.Path(__file__).parent.parent / "schema" / "schemas" / "PraticaImpiantoCEMRL_v01.10.xsd"
    schema = xmlschema.XMLSchema(XSD)
    new_map: dict[str, list[str]] = {}
    for c in schema.types.values():
        if not c.name or not hasattr(c, "content") or not getattr(c, "content"):
            continue
        seq = [e.name for e in getattr(c.content, "iter_elements", lambda: [])()]
        if seq:
            new_map[c.name] = seq
    ORDER_FILE.write_text(json.dumps(new_map, indent=2, ensure_ascii=False))
    print("✅  order_map.json rigenerato")

if __name__ == "__main__":
    _dump_order_map()


import re

_snake_re = re.compile(r"_([a-z])")  # memoised

_SPECIAL_XML_TAGS = {
    "quota_ce": "QuotaCE",
    "quotace":  "QuotaCE",
    "alfa_pc":  "AlfaPC",
    "alfapc":   "AlfaPC",
    "alfa_dtx": "AlfaDTX",
    "alfadtx":  "AlfaDTX",
    "fpr":      "FPR",
    "ftc":      "FTC",
    "num_portanti_attivabili": "NumPortantiAttivabili",
    "potenza_totale_connettore": "PotenzaTotaleConnettore",
    "potenza_irradiata_connettore": "PotenzaIrradiataConnettore",
    # Add more cases here if needed
}

_ACRONYM_RE = re.compile(r"_[A-Z]{2,3}$")   # e.g., _CE, _PC, _DTX

# Acronyms that should remain fully uppercase
_ACRONYMS = {"ce": "CE", "pc": "PC", "dtx": "DTX"}

def snake_to_camel(name: str) -> str:
    """Convert snake_case to CamelCase, handling specific acronyms."""
    parts = name.split("_")
    # First segment: capitalize the first letter, lowercase the rest
    camel = [parts[0].capitalize()]
    # Other segments
    for p in parts[1:]:
        camel.append(_ACRONYMS.get(p, p.capitalize()))
    return "".join(camel)


def dict_snake_to_camel(data: dict) -> dict:
    """Convert all keys in a nested dictionary to camel-case."""
    if isinstance(data, dict):
        new = {}
        for k, v in data.items():
            new[snake_to_camel(k)] = dict_snake_to_camel(v)
        return new
    elif isinstance(data, list):
        return [dict_snake_to_camel(i) for i in data]
    else:
        return data


_ACRONYMS = {
    "id":  "ID",
    "gps": "GPS",
    "rf":  "RF",
    "ce":  "CE",  # Already present
    # Add more acronyms as needed
}

def snake_to_camel(name: str) -> str:
    """
    Convert snake_case to CamelCase, handling specific acronyms.
    Example: 'quota_ce' -> 'QuotaCE'
    """
    chunks = name.split("_")
    # First chunk remains lowercase if you want lowerCamel, otherwise .title()
    first = chunks[0].title()

    rest = []
    for chunk in chunks[1:]:
        # Use the 'raw' (lowercase) form to check for acronyms
        acr = _ACRONYMS.get(chunk.lower())
        if acr:
            rest.append(acr)  # CE, ID, RF, ...
        else:
            rest.append(chunk.title())  # Porta, Impianto, ...
    return first + "".join(rest)

def _part_to_camel(part: str) -> str:
    """
    Convert part according to these rules:
    - If the part matches a known acronym, return it in uppercase.
    - Otherwise, capitalize (first letter uppercase, rest lowercase).
    """
    return _ACRONYMS.get(part.lower(), part.capitalize())

def snake_to_camel(name: str) -> str:
    if "_" not in name:  # Already CamelCase, do not alter
        return name
    return "".join(_part_to_camel(p) for p in name.split("_") if p)

def dict_snake_to_camel(obj):
    """
    Recursively convert snake_case keys to CamelCase
    in dict, list, tuple, or dataclass/object with __dict__.
    """
    # 1. Dict → convert keys and recursively call on values
    if isinstance(obj, dict):
        return {
            snake_to_camel(k): dict_snake_to_camel(v)
            for k, v in obj.items()
        }

    # 2. List or tuple → convert each element
    if isinstance(obj, list):
        return [dict_snake_to_camel(v) for v in obj]
    if isinstance(obj, tuple):
        return tuple(dict_snake_to_camel(v) for v in obj)

    # 3. Dataclass or generic object → try to read __dict__
    if hasattr(obj, "__dict__"):
        return dict_snake_to_camel(vars(obj))

    # 4. Base case: simple value
    return obj

def camel_to_snake(s: str) -> str:
    ...

def dict_snake_to_camel(obj: Any) -> Any:
    """Recursively convert dictionary keys from snake_case to CamelCase."""
    if isinstance(obj, dict):
        new = {}
        for k, v in obj.items():
            ck = snake_to_camel(k)
            if ck.lower() == "versione":  # Intercept any casing
                ck = "Versione"
            new[ck] = dict_snake_to_camel(v)
        return new
    if isinstance(obj, list):
        return [dict_snake_to_camel(x) for x in obj]
    return obj
