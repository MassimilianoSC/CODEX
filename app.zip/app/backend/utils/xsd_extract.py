from pathlib import Path
import xml.etree.ElementTree as ET

NS = {"xs": "http://www.w3.org/2001/XMLSchema"}

def extract_spec(xsd_path: Path):
    tree = ET.parse(xsd_path)
    root = tree.getroot()

    spec = {}

    def walk(elem, xpath=""):
        tag_name = elem.get("name")
        if tag_name:
            cur = f"{xpath}/{tag_name}" if xpath else tag_name

            # --- tipo di dato -------------------------------------------------
            xsd_type = (
                    elem.get("type")  # attributo diretto
                    or elem.findtext(".//xs:restriction/@base", namespaces=NS)  # base di restriction
                    or "xs:string"  # fallback
            )

            # --- enumeration (se c'è) ----------------------------------------
            enums = [e.get("value") for e in elem.findall(".//xs:enumeration", NS)] or None

            spec[cur] = {"type": xsd_type, "enum": enums}

            # --- SCENDI in tutti gli xs:element discendenti -------------------
            for child in elem.findall(".//xs:element", NS):
                # evita di riciclare l'elemento corrente
                if child is not elem:
                    walk(child, cur)

    for top in root.findall("xs:element", NS):
        walk(top)

    return spec


if __name__ == "__main__":
    p = Path("app/backend/schema/schemas/PraticaImpiantoCEMRL_v01.10.xsd")
    spec = extract_spec(p)
    print("Totale campi:", len(spec))
    for k in list(spec)[:10]:
        print(k, spec[k])
