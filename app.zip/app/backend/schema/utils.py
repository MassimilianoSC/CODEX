"""
Utility per l'estrazione di metadati dallo schema XSD.
"""

import xmlschema
from pathlib import Path

XSD = xmlschema.XMLSchema(
    Path(__file__).parent / 'schemas' / 'PraticaImpiantoCEMRL_v01.10.xsd'
)

def get_required_flags(type_name: str) -> dict[str, bool]:
    """
    Restituisce un dict {elemento: minOccurs>0?} per un complexType.
    """
    st = XSD.types.get(type_name)
    flags = {}
    if st is not None and st.is_complex():
        for e in st.content.iter_elements():
            flags[e.name] = e.min_occurs > 0
    return flags