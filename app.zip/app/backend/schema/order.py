# order.py
import json
from pathlib import Path
from collections import OrderedDict

# Load mapping of element order from XSD-derived JSON
ORDER_MAP_PATH = Path(__file__).parent / 'schemas' / 'order_map.json'
ORDER_MAP = json.loads(ORDER_MAP_PATH.read_text(encoding='utf-8'))

def ordered(data: dict, type_name: str) -> OrderedDict:
    seq = ORDER_MAP.get(type_name, [])
    out = OrderedDict()
    # include keys in XSD-defined sequence
    for k in seq:
        if k in data:
            val = data[k]
            # recursive ordering for nested dicts/lists
            if isinstance(val, dict):
                val = ordered(val, k + 'Type')
            elif isinstance(val, list):
                val = [ordered(v, k + 'Type') if isinstance(v, dict) else v for v in val]
            out[k] = val
    # append any additional keys
    for k, v in data.items():
        if k not in out:
            out[k] = v
    return out
