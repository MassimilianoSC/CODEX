# convert.py
from typing import Any

def snake_to_camel(name: str) -> str:
    parts = name.split('_')
    acronyms = {'ce': 'CE', 'pc': 'PC', 'dtx': 'DTX'}
    return ''.join(acronyms.get(p, p.title()) for p in parts)


def dict_snake_to_camel(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {snake_to_camel(k): dict_snake_to_camel(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [dict_snake_to_camel(v) for v in obj]
    return obj
