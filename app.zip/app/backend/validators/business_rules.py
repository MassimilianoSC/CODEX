# business_rules.py
def validate_business_rules(xml_doc):
    """Stub temporaneo: ritorna sempre OK."""
    return True, []
