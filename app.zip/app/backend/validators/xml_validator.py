"""
XML Validator for PraticaImpiantoCEMRL files.
Validates XML files against the XSD schema.
"""

import os
from dataclasses import dataclass
from pathlib import Path
from typing import List, Union, Optional
import xmlschema
import logging
from xmlschema.validators.exceptions import XMLSchemaValidationError
from lxml import etree
import re

# ─────── 1. definisci subito il percorso dello XSD ───────
XSD_PATH = (
    Path(__file__).resolve().parent.parent  # .../backend
    / "schema" / "schemas" / "PraticaImpiantoCEMRL_v01.10.xsd"
)
# ──────────────────────────────────────────────────────────

logger = logging.getLogger(__name__)


@dataclass
class ValidationError:
    """Represents a validation error in an XML file."""
    path: str
    line: int
    column: int
    message: str
    
    def __str__(self) -> str:
        return f"Line {self.line}, Col {self.column}, Path: {self.path} - {self.message}"


def humanize_error(exc: XMLSchemaValidationError, schema: xmlschema.XMLSchema) -> str:
    # Extract element name from path, removing any [index]
    raw = exc.path.rsplit('/', 1)[-1]
    elem_name = re.sub(r'\[\d+\]$', '', raw)

    # recupera la definizione XSD
    xsd_elem = schema.elements.get(elem_name)
    if xsd_elem and hasattr(xsd_elem.type, 'facets') and 'enumeration' in xsd_elem.type.facets:
        allowed_entries = []
        for facet in xsd_elem.type.facets['enumeration']:
            val = facet.value
            doc = ''
            if facet.annotation is not None and getattr(facet.annotation, 'documentation', None):
                docs = facet.annotation.documentation
                if docs and docs[0].text:
                    doc = docs[0].text.strip()
            entry = f"{val} ({doc})" if doc else str(val)
            allowed_entries.append(entry)

        allowed_str = ", ".join(allowed_entries)
        return (
            f"Campo «{elem_name}»: il valore «{exc.object}» non è consentito.\n"
            f"Valori ammessi: {allowed_str}.\n"
            "Apri l'XML e sostituisci il valore con uno di quelli indicati."
        )

    # fallback generico - restore the field name prefix
    reason = getattr(exc, 'reason', None) or getattr(exc, 'message', str(exc))
    return f"Errore di validazione nel campo «{elem_name}»: {reason}"


class XMLValidator:
    """
    Validator for XML files against an XSD schema.
    """

    def __init__(self, schema_path: Union[str, Path] = XSD_PATH):
        p = Path(schema_path)
        if not p.is_absolute():
            p = Path(__file__).parent / p
        if not p.exists():
            p = Path(__file__).parent.parent / p.name
        if not p.exists():
            raise FileNotFoundError(f"Schema file not found: {p!s}")
        self.schema_path = p

        try:
            self.schema = xmlschema.XMLSchema(str(self.schema_path))
            logger.info("Validator ready, schema=%s", self.schema_path)
        except xmlschema.XMLSchemaException as e:
            raise xmlschema.XMLSchemaException(f"Invalid schema: {e}")

    def _to_validation_error(self, exc: XMLSchemaValidationError) -> ValidationError:
        human = humanize_error(exc, self.schema)
        line, col = getattr(exc, 'position', (0, 0))
        return ValidationError(path=exc.path or '/', line=line, column=col, message=human)

    def validate(self, xml_path: Union[str, Path]) -> List[ValidationError]:
        xml_path = Path(xml_path)
        logger.debug("Validate file: %s", xml_path)
        errors: List[ValidationError] = []
        try:
            self.schema.validate(str(xml_path))
            logger.debug("XML %s valido ‒ nessun errore XSD", xml_path)
            return []
        except XMLSchemaValidationError as first_exc:
            errors.append(self._to_validation_error(first_exc))
        # raccolgo tutti gli errori successivi
        for exc in self.schema.iter_errors(str(xml_path)):
            errors.append(self._to_validation_error(exc))
        return errors

    def validate_string(self, xml_string: str) -> List[ValidationError]:
        """
        Validates an XML string against the schema.
        Always returns a list of ValidationError objects, empty if validation succeeds.
        """
        errors: List[ValidationError] = []
        try:
            self.schema.validate(xml_string)
            return errors  # Return empty list on success
        except XMLSchemaValidationError as first_exc:
            errors.append(self._to_validation_error(first_exc))
        # Collect all subsequent errors
        for exc in self.schema.iter_errors(xml_string):
            errors.append(self._to_validation_error(exc))
        return errors

    def get_schema_elements(self) -> List[str]:
        elements = []
        for name, element in self.schema.elements.items():
            elements.append(name)
        return elements

    def get_schema_types(self) -> List[str]:
        types = []
        for name, type_def in self.schema.types.items():
            types.append(name)
        return types


if __name__ == "__main__":
    # Example usage
    print("This module is not meant to be run directly.")