"""
Data models for PraticaImpiantoCEMRL XML files.
"""

from __future__ import annotations
import warnings                                     # già presente altrove

from typing import TYPE_CHECKING
from dataclasses import dataclass, field, fields

from enum import IntEnum, Enum
import logging
from typing import List, Optional, Dict, Any, TypeVar, Union
# Import helper for ordering XML tags
#from app.backend.schema.order import ordered ########### reinserisci questo ed elimina quello sotto 
from app.backend.schema.order import ordered
from app.backend.models.utils import _safe_enum

# Import the module and the specific enum class
from . import enums
from .enums import TECNOLOGIATYPE

from app.backend.models.crel.crelprogettosrb import CRELProgettoSRB
from app.backend.models.crel.filemsi import FileMsi

# --- enum generati dallo XSD -----------------------------
from .enums import (
    TIPOPRATICATYPE,
    TIPOMISURATYPE,
    TIPOANTENNATYPE,
    POLARIZZAZIONETYPE,
    PMCTYPE,
    UNITAMISURATYPE,
    PROVINCELIGURITYPE,
    SINOTYPE,
    ESPOSIZIONETYPE,
)

# alias per compatibilità con webapp/forms.py
TipoPratica       = TIPOPRATICATYPE
TipoMisura        = TIPOMISURATYPE
TipoAntenna       = TIPOANTENNATYPE
Tecnologia        = TECNOLOGIATYPE
Polarizzazione    = POLARIZZAZIONETYPE
PMC               = PMCTYPE
UnitaMisura       = UNITAMISURATYPE  # oppure lascia la tua classe UnitaMisura, se preferisci
ProvinciaLigure   = PROVINCELIGURITYPE
SiNo              = SINOTYPE         # oppure la classe SiNo già definita in questo modulo
LimiteEsposizione = ESPOSIZIONETYPE
# ---------------------------------------------------------

# --------------------------------------------------------------------- 
# tracking per evitare milioni di warning tutti uguali 
_logged_bad_values: set[tuple[str, str]] = set()

# Configure logger
log = logging.getLogger(__name__)

def _safe_int(d: Dict[str, Any], key: str) -> Optional[int]:
    try:
        return int(d[key]) if key in d and d[key] != "" else None
    except (ValueError, TypeError):
        return None

def _safe_float(d: Dict[str, Any], key: str) -> Optional[float]:
    try:
        return float(d[key]) if key in d and d[key] != "" else None
    except (ValueError, TypeError):
        return None

# Remove the old enum classes (TipoPratica, TipoAntenna, Polarizzazione, TipoMisura, Tecnologia, PMC)
# Keep only the ones that aren't replaced by the new imports

class UnitaMisura(str, Enum):
    """Unità misura enumeration."""
    VOLT_METRO = "P9"
    AMPERE_METRO = "P10"
    NUMERO = "P11"

class SiNo(str, Enum):
    """Si/No enumeration."""
    SI = "SI"
    NO = "NO"

# Remove LimiteEsposizione class as it's replaced by ESPOSIZIONETYPE

T = TypeVar('T')

@dataclass
class ModelloAntenna:
    """Modello antenna data."""
    codice_modello_antenna: int = 0  # Ensure it's an integer

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ModelloAntenna':
        # Always cast to int
        return cls(codice_modello_antenna=int(data['CodiceModelloAntenna']))

    def to_dict(self) -> Dict[str, Any]:
        # Already returns an integer
        return {'CodiceModelloAntenna': self.codice_modello_antenna}

# Continua con la definizione di Misura e il resto del file
@dataclass
class Misura:
    """Misura data."""
    # --- campi obbligatori ---
    tipo_misura: TIPOMISURATYPE = TIPOMISURATYPE.E_MISURATO
    data_misura: str = ""
    pmc: PMCTYPE = PMCTYPE.CAMPO_ELETTRICO_CEI_211_7_BANDA_LARGA
    unita_misura: UNITAMISURATYPE = UNITAMISURATYPE.VOLT_METRO
    valore_misurato: Optional[float] = None
    canale: Optional[int] = None
    frequenza_min: Optional[float] = None
    frequenza_max: Optional[float] = None
    alfa_pc: Optional[float] = None
    alfa_dtx: Optional[float] = None
    rho: Optional[float] = None
    nrs: Optional[float] = None
    bf: Optional[float] = None
    alfa24_max: Optional[float] = None
    alfa24_day: Optional[float] = None

    # --- campi opzionali ---
    tecnologia: TECNOLOGIATYPE | None = None
    settore: Optional[str] = None
    note_misura: Optional[str] = None
    ora_misura: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Misura':
        log.debug("IN %s: %s", cls.__name__, {k: v for k, v in data.items()})
        tipo_val = _safe_int(data, 'TipoMisura') or 1
        tipo = TIPOMISURATYPE(tipo_val)
        pmc_val = _safe_int(data, 'PMC') or 2
        pmc = PMCTYPE(pmc_val)
        unita_val = data.get('UnitaMisura', 'P9')
        unita = UNITAMISURATYPE(unita_val)
        tec_val = data.get('tecnologia', data.get('Tecnologia'))
        tecnologia = _safe_enum(TECNOLOGIATYPE, tec_val)
        return cls(
            tipo_misura=tipo,
            data_misura=data.get('DataMisura', ''),
            pmc=pmc,
            unita_misura=unita,
            valore_misurato=float(data.get('ValoreMisurato', 0.0)),
            canale=_safe_int(data, 'Canale'),
            frequenza_min=float(data['FrequenzaMin']) if data.get('FrequenzaMin') else None,
            frequenza_max=float(data['FrequenzaMax']) if data.get('FrequenzaMax') else None,
            alfa_pc=float(data['AlfaPC']) if data.get('AlfaPC') else None,
            alfa_dtx=float(data['AlfaDTX']) if data.get('AlfaDTX') else None,
            rho=float(data['Rho']) if data.get('Rho') else None,
            nrs=float(data['Nrs']) if data.get('Nrs') else None,
            bf=float(data['Bf']) if data.get('Bf') else None,
            alfa24_max=float(data['Alfa24Max']) if data.get('Alfa24Max') else None,
            alfa24_day=float(data['Alfa24Day']) if data.get('Alfa24Day') else None,
            tecnologia=tecnologia,
            settore=data.get('Settore'),
            note_misura=data.get('NoteMisura'),
            ora_misura=data.get('OraMisura')
        )

    def to_dict(self) -> Dict[str, Any]:
        print(
            f"[DBG-Misura] tipo_misura={self.tipo_misura}  tecnologia={self.tecnologia!r}"
        )
        tmp = {
            'TipoMisura': self.tipo_misura.value,
            'DataMisura': self.data_misura,
            'PMC': self.pmc.value,
            'UnitaMisura': self.unita_misura,
            'ValoreMisurato': _fmt(self.valore_misurato),
        }

        # Campi opzionali
        if self.tecnologia is not None:
            tmp['Tecnologia'] = self.tecnologia.value
        _add_if(tmp, 'Settore', self.settore)
        _add_if(tmp, 'Canale', self.canale)
        _add_if(tmp, 'FrequenzaMin', _fmt(self.frequenza_min))
        _add_if(tmp, 'FrequenzaMax', _fmt(self.frequenza_max))
        _add_if(tmp, 'AlfaPC', _fmt(self.alfa_pc))
        _add_if(tmp, 'AlfaDTX', _fmt(self.alfa_dtx))
        _add_if(tmp, 'Rho', _fmt(self.rho))
        _add_if(tmp, 'Nrs', _fmt(self.nrs))
        _add_if(tmp, 'Bf', _fmt(self.bf))
        _add_if(tmp, 'Alfa24Max', _fmt(self.alfa24_max))
        _add_if(tmp, 'Alfa24Day', _fmt(self.alfa24_day))
        _add_if(tmp, 'NoteMisura', self.note_misura)
        if self.ora_misura:  # solo se valorizzata (es. "09:00")
            tmp["OraMisura"] = self.ora_misura

        return {k: v for k, v in tmp.items() if v is not None}

@dataclass
class PuntoMisura:
    # --- campi obbligatori ---
    codifica_gestore: str = ""
    descrizione_punto: str = ""
    coordinata_x: Optional[int] = None
    coordinata_y: Optional[int] = None
    quota: Optional[float] = None
    distanza: Optional[float] = None
    direzione: Optional[float] = None
    dislivello: Optional[float] = None
    limite_esposizione: ESPOSIZIONETYPE = ESPOSIZIONETYPE.LIMITE_DI_LEGGE

    # --- campi opzionali ---
    fattore_attenuazione: Optional[float] = None
    note_fattore_attenuazione: Optional[str] = None
    misure: List[Misura] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'PuntoMisura':
        log.debug("IN %s: %s", cls.__name__, {k: v for k, v in data.items()})
        limite_val = _safe_int(data, 'LimiteEsposizione') or 1
        limite = ESPOSIZIONETYPE(limite_val)
        misure_data = data.get('Misura', [])
        if not isinstance(misure_data, list):
            misure_data = [misure_data]
        misure = [Misura.from_dict(m) for m in misure_data]

        # -----------------------------------------------------------------
        # Gestione robusta dei possibili alias:
        #   • 'Distanza', 'distanza'  (minuscolo)
        #   • '@Distanza'             (valore come attributo XML)
        # Idem per Direzione
        # -----------------------------------------------------------------
        def _first_value(*keys):
            for k in keys:
                if k in data and data[k] not in ("", None):
                    return data[k]
            return None

        dist_val = _first_value('Distanza', 'distanza', '@Distanza')
        dir_val  = _first_value('Direzione', 'direzione', '@Direzione')

        distanza  = float(dist_val) if dist_val is not None else None
        direzione = float(dir_val)  if dir_val  is not None else None

        return cls(
            codifica_gestore=data.get('CodificaGestore') or "",
            descrizione_punto=data.get('DescrizionePunto') or "",
            coordinata_x=int(data.get('CoordinataX', 0)),
            coordinata_y=int(data.get('CoordinataY', 0)),
            quota=float(data['Quota']) if data.get('Quota') else None,
            distanza=distanza,
            direzione=direzione,
            dislivello=float(data.get('Dislivello', 0.0)),
            limite_esposizione=limite,
            fattore_attenuazione=_safe_float(data, 'FattoreAttenuazione'),
            note_fattore_attenuazione=data.get('NoteFattoreAttenuazione'),
            misure=misure
        )

    def to_dict(self) -> Dict[str, Any]:
        from app.backend.schema.order import ordered

        # Campi obbligatori nell'ordine esatto richiesto dallo schema
        tmp: Dict[str, Any] = {
            "CodificaGestore": self.codifica_gestore,
            "DescrizionePunto": self.descrizione_punto,
            "CoordinataX": self.coordinata_x,
            "CoordinataY": self.coordinata_y,
            "Quota": _fmt(self.quota, keep_zero=True),  # Required field
            "Distanza": _fmt(self.distanza, keep_zero=True),  # Required field
            "Direzione": _fmt(self.direzione, keep_zero=True),  # Required field
            "Dislivello": _fmt(self.dislivello, keep_zero=True),  # Required field
            "LimiteEsposizione": self.limite_esposizione,
        }

        # Campi opzionali (non need keep_zero)
        _add_if(tmp, "FattoreAttenuazione", _fmt(self.fattore_attenuazione))
        _add_if(tmp, "NoteFattoreAttenuazione", self.note_fattore_attenuazione)

        # Misure (solo se presenti)
        if self.misure:
            tmp["Misura"] = [m.to_dict() for m in self.misure] if len(self.misure) > 1 else self.misure[0].to_dict()

        return {k: v for k, v in tmp.items() if v is not None}

# --- helper per un CRELProgettoSRB "blank" ----------------------------
def _blank_crel() -> "CRELProgettoSRB":
    """
    Ritorna un CRELProgettoSRB con tutti i campi inizializzati
    (lista vuota per file_msi, None per il resto).
    """
    from app.backend.models.crel.crelprogettosrb import CRELProgettoSRB
    from dataclasses import fields

    values = {
        f.name: ([] if f.name == "file_msi" else None)
        for f in fields(CRELProgettoSRB)
    }
    return CRELProgettoSRB(**values)
# ---------------------------------------------------------------------

@dataclass
class Sistema:
    """Sistema data."""
    identificativo_sistema: str = "1"
    sistema_attivo: SiNo = SiNo.NO

    # The only allowed CREL block
    crel_progetto: CRELProgettoSRB = field(default_factory=_blank_crel)

    @classmethod
    def from_dict(cls, data: dict) -> "Sistema":
        # Create an empty block if missing
        crel_data = data.get("CRELProgettoSRB", {})
        return cls(
            identificativo_sistema=data.get("IdentificativoSistema", "1"),
            sistema_attivo=SiNo(data.get("SistemaAttivo", "NO")),
            crel_progetto=CRELProgettoSRB.from_dict(crel_data),
        )

    def __post_init__(self):
        # Non validare un blocco vuoto iniziale
        if self.crel_progetto and not any(
            getattr(self.crel_progetto, f.name) not in (None, '', [])
            for f in fields(self.crel_progetto)
            if f.metadata.get("required")
        ):
            return

        # Valida solo se ci sono dati
        if not self.crel_progetto.is_valid():
            missing = []
            for f in fields(self.crel_progetto):
                value = getattr(self.crel_progetto, f.name)
                print(f"### FIELD CHECK: {f.name} = {value!r}")
                if f.metadata.get("required") and (
                    value is None or
                    (isinstance(value, str) and value.strip() == '') or
                    (isinstance(value, list) and len(value) == 0)
                ):
                    missing.append(f.name)
            warnings.warn(
                f"CRELProgettoSRB incompleto: {missing}",
                RuntimeWarning,
            )


    def to_dict(self) -> Dict[str, Any]:
        tmp = {
            "IdentificativoSistema": self.identificativo_sistema,
            "SistemaAttivo": self.sistema_attivo.value
                            if isinstance(self.sistema_attivo, Enum)
                            else self.sistema_attivo,
            "CRELProgettoSRB": self.crel_progetto.to_dict(),
        }
        return {k: v for k, v in ordered(tmp, "SistemaType").items() if v is not None}

@dataclass
class Impianto:
    """Impianto data."""
    # Required fields with specific types and defaults
    codice_gestore: str = ""
    descrizione: str = ""
    ragione_sociale: str = ""
    identificativo_impianto: str = ""
    cod_prov: str = ""
    cod_com: str = ""
    indirizzo_localita: str = ""
    coordinata_x: Optional[int] = None
    coordinata_y: Optional[int] = None
    quota_base: Optional[float] = None
    referente: str = ""
    # Optional fields with defaults
    data_inizio_gestione: Optional[str] = None
    proto_concessione_ministeriale: Optional[str] = None
    note_impianto: Optional[str] = None
    sistemi: List[Sistema] = field(default_factory=list)
    punti_misura: List[PuntoMisura] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Impianto":
        print("DEBUG DataInizioGestione:", data.get('DataInizioGestione'))
        sistemi_data = data.get("Sistema", [])
        if not isinstance(sistemi_data, list):
            sistemi_data = [sistemi_data]
        sistemi = [Sistema.from_dict(s) for s in sistemi_data if s]

        punti_data = data.get("PuntoMisura", [])
        if not isinstance(punti_data, list):
            punti_data = [punti_data]
        punti = [PuntoMisura.from_dict(p) for p in punti_data if p]

        return cls(
            codice_gestore=data.get("CodiceGestore", ""),
            descrizione=data.get("Descrizione", ""),
            ragione_sociale=data.get("RagioneSociale", ""),
            identificativo_impianto=data.get("IdentificativoImpianto", ""),
            data_inizio_gestione=data.get("DataInizioGestione") or None,
            proto_concessione_ministeriale=data.get("ProtoConcessioneMinisteriale"),
            cod_prov=data.get("CodProv", ""),
            cod_com=data.get("CodCom", ""),
            indirizzo_localita=data.get("IndirizzoLocalita", ""),
            coordinata_x=int(data.get("CoordinataX", 0)),
            coordinata_y=int(data.get("CoordinataY", 0)),
            quota_base=float(data.get("QuotaBase", 0.0)),
            note_impianto=data.get("NoteImpianto"),
            referente=data.get("Referente", ""),
            sistemi=sistemi,
            punti_misura=punti
        )

    def to_dict(self) -> Dict[str, Any]:
        from app.backend.schema.order import ordered

        tmp: Dict[str, Any] = {
            "CodiceGestore": self.codice_gestore,
            "Descrizione": self.descrizione,
            "RagioneSociale": self.ragione_sociale,
            "IdentificativoImpianto": self.identificativo_impianto,
        }

        _add_if(tmp, "DataInizioGestione", self.data_inizio_gestione)
        _add_if(tmp, "ProtoConcessioneMinisteriale", self.proto_concessione_ministeriale)

        if self.cod_prov:
            tmp["CodProv"] = str(self.cod_prov).zfill(3)

        if self.cod_com:
            tmp["CodCom"] = str(self.cod_com).zfill(3)

        tmp["IndirizzoLocalita"] = self.indirizzo_localita or ""
        tmp["CoordinataX"] = self.coordinata_x
        tmp["CoordinataY"] = self.coordinata_y
        tmp["QuotaBase"] = _fmt(self.quota_base, keep_zero=True)  # Required field

        _add_if(tmp, "NoteImpianto", self.note_impianto)
        _add_if(tmp, "Referente", self.referente)

        if self.sistemi:
            tmp["Sistema"] = [s.to_dict() for s in self.sistemi] if len(self.sistemi) > 1 else self.sistemi[0].to_dict()

        if self.punti_misura:
            tmp["PuntoMisura"] = [p.to_dict() for p in self.punti_misura] if len(self.punti_misura) > 1 else self.punti_misura[0].to_dict()

        return ordered(tmp, "ImpiantoType")

@dataclass
class PraticaImpiantoCEMRL:
    """Root model for PraticaImpiantoCEMRL XML."""
    tipo_pratica: TIPOPRATICATYPE = TIPOPRATICATYPE.AIE
    impianti: List[Impianto] = field(default_factory=list)
    note_pratica: Optional[str] = None
    versione: str = "01.10"

    def __post_init__(self):
        # Keep your validation logic
        if not self.impianti:
            raise ValueError("Errore XSD: la pratica deve contenere almeno un <Impianto>")

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'PraticaImpiantoCEMRL':
        """Costruisce una pratica da un dizionario."""
        # trova qualunque chiave che corrisponda a 'impianto' ignorando il case
        imp_key = next((k for k in data if k.lower() == "impianto"), None)
        if not imp_key:
            raise ValueError("Errore XSD: la pratica deve contenere almeno un <Impianto>")

        imp_data = data[imp_key]
        if not isinstance(imp_data, list):
            imp_data = [imp_data]

        impianti = []
        for imp in imp_data:
            imp_obj = Impianto.from_dict(imp)
            # Normalizza gli ID dei sistemi solo se necessario
            _normalize_system_ids(imp_obj.sistemi)
            impianti.append(imp_obj)
        
        return cls(
            tipo_pratica=TipoPratica(int(data["TipoPratica"])) if "TipoPratica" in data else TipoPratica.AIE,
            impianti=impianti,
            note_pratica=data.get("NotePratica"),
            versione=data.get("@Versione", "01.10")
        )

    def to_dict(self) -> Dict[str, Any]:
        from app.backend.schema.order import ordered

        tmp = {
            "@Versione": self.versione,
            "TipoPratica": self.tipo_pratica.value,
        }

        if self.tipo_pratica is not None and str(self.tipo_pratica) != "":
            tmp["TipoPratica"] = self.tipo_pratica.value if hasattr(self.tipo_pratica, "value") else self.tipo_pratica

        if self.note_pratica:
            tmp["NotePratica"] = self.note_pratica

        if self.impianti:
            if len(self.impianti) > 1:
                tmp["Impianto"] = [i.to_dict() for i in self.impianti]
            else:
                tmp["Impianto"] = self.impianti[0].to_dict()

        # ❗ Ordina TUTTO secondo order_map.json
        return ordered(tmp, "PraticaImpiantoCEMRLType")

def _fmt(n, keep_zero=False):
    """Formatta un numero rimuovendo gli zeri decimali non necessari.
    Se keep_zero=True, mantiene i valori 0 anche se sono considerati "vuoti".
    """
    if n in (None, ''):
        return None
    if not keep_zero and str(n) in ('0', '0.0'):
        return None
    return str(n).rstrip('0').rstrip('.')

def _add_if(tmp: dict, key: str, val):
    """Aggiunge il tag solo se value è significativo."""
    if val not in (None, '', 0, 0.0, '0'):
        tmp[key] = val

def _normalize_system_ids(sistemi: List[Sistema]) -> None:
    """
    Normalizza gli identificativi dei sistemi solo se ci sono duplicati.
    """
    ids = [s.identificativo_sistema for s in sistemi]
    if len(ids) != len(set(ids)):
        # solo se duplicati
        for i, s in enumerate(sistemi, 1):
            s.identificativo_sistema = str(i)

if __name__ == "__main__":
    print("Questo modulo non va eseguito direttamente.")
