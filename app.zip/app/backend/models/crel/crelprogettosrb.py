from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any

from app.backend.models.crel.base import CRELBase
from app.backend.models.crel.filemsi import FileMsi
from app.backend.schema.utils import get_required_flags
#from app.backend.schema.order import ordered
from app.backend.schema.order import ordered
import logging 
from app.backend.models.enums import TECNOLOGIATYPE 
from app.backend.models.utils import _safe_enum

# Carica i flag required direttamente dallo XSD (minOccurs > 0)
_FIELDS: Dict[str, bool] = get_required_flags('CRELProgettoSRBType')

@dataclass
class CRELProgettoSRB(CRELBase):
    # ---------- obbligatori ----------
    tipo_antenna: int = field(metadata={'required': True})
    modello_antenna: int = field(metadata={'required': True})
    tecnologia: TECNOLOGIATYPE = field(metadata={'required': True})
    azimut: Optional[int] = field(default=None, metadata={'required': True})
    quota_ce: Optional[float] = field(default=None, metadata={'required': True})
    tilte: Optional[float] = field(default=None, metadata={'required': True})
    tilte_min: Optional[float] = field(default=None, metadata={'required': True})
    tilte_max: Optional[float] = field(default=None, metadata={'required': True})
    tiltm: Optional[float] = field(default=None, metadata={'required': True})
    tiltm_min: Optional[float] = field(default=None, metadata={'required': True})
    tiltm_max: Optional[float] = field(default=None, metadata={'required': True})
    num_portanti_attivabili: Optional[int] = field(default=None, metadata={'required': True})
    potenza_totale_connettore: Optional[float] = field(default=None, metadata={'required': True})
    alfa24: Optional[float] = field(default=None, metadata={'required': True})   
    alfa_pc: Optional[float] = field(default=None, metadata={'required': True})
    alfa_dtx: Optional[float] = field(default=None, metadata={'required': True})
    eirp: Optional[float] = field(default=None, metadata={'required': True})
    guadagno: Optional[float] = field(default=None, metadata={'required': True})

    # ---------- opzionali ----------
    file_msi: List[FileMsi] = field(default_factory=list, metadata={'required': True})
    settore: Optional[str] = field(default=None, metadata={'required': _FIELDS.get('Settore', False)})
    potenza_nominale: Optional[float] = field(default=None, metadata={'required': _FIELDS.get('PotenzaNominale', False)})
    perdita_trasmissione: Optional[float] = field(default=None, metadata={'required': _FIELDS.get('PerditaTrasmissione', False)})
    polarizzazione: Optional[str] = field(default=None, metadata={'required': _FIELDS.get('Polarizzazione', False)})
    sito_rif_alfa_24: Optional[str] = field(default=None, metadata={'required': _FIELDS.get('SitoRifAlfa24', False)})
    fpr: Optional[float] = field(default=None, metadata={'required': _FIELDS.get('Fpr', False)})
    ftc: Optional[float] = field(default=None, metadata={'required': _FIELDS.get('Ftc', False)})
    potenza_irradiata_connettore: Optional[float] = field(default=None, metadata={'required': _FIELDS.get('PotenzaIrradiataConnettore', False)})
    coordinata_x: Optional[int] = field(default=None, metadata={'required': _FIELDS.get('CoordinataX', False)})
    coordinata_y: Optional[int] = field(default=None, metadata={'required': _FIELDS.get('CoordinataY', False)})
    coordinata_z: Optional[float] = field(default=None, metadata={'required': _FIELDS.get('CoordinataZ', False)})

    # ----------------------------------------------------------------- 
    def __post_init__(self): 
        # Normalizza il campo Tecnologia se fuori enum 
        self.tecnologia = _safe_enum(TECNOLOGIATYPE, self.tecnologia) 
    # ----------------------------------------------------------------- 

    # --- AGGIUNGERE QUI -------------------------------------------------
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CRELProgettoSRB":
        """
        • Estrae l'int interno da <ModelloAntenna>
        • Converte FileMsi in lista di dataclass
        • Lascia a CRELBase il resto della conversione CamelCase → snake_case
        """
        data = dict(data)  # copia difensiva

        # 1) ModelloAntenna -> int
        if "ModelloAntenna" in data and isinstance(data["ModelloAntenna"], dict):
            codice = data["ModelloAntenna"].get("CodiceModelloAntenna")
            data["ModelloAntenna"] = int(codice) if codice is not None else None

        # 2) FileMsi -> list[FileMsi]
        if "FileMsi" in data:
            raw = data["FileMsi"]
            if not isinstance(raw, list):
                raw = [raw]
            data["FileMsi"] = [FileMsi.from_dict(d) for d in raw if d]

        # 3) SitoRifAlfa24 -> chiave snake corretta
        if "SitoRifAlfa24" in data:
            data["sito_rif_alfa_24"] = data["SitoRifAlfa24"]

        # PATCH: tecnologia può essere snake_case o CamelCase
        tec_val = data.get('tecnologia') or data.get('Tecnologia')
        if tec_val is not None:
            try:
                tecnologia = TECNOLOGIATYPE(int(tec_val))
            except Exception:
                tecnologia = None
        else:
            tecnologia = None
        print("DEBUG TECNO:", tec_val, tecnologia, type(tecnologia))
        if tecnologia is not None:
            data['Tecnologia'] = tecnologia

        return super().from_dict(data)
    # -------------------------------------------------------------------

    def to_dict(self) -> Dict[str, Any]:
        # base → snake keys
        d = super().to_dict()
    
        # --- mappa snake → Camel per i campi rimasti ---
        snake2camel = {
            "tipo_antenna": "TipoAntenna",
            "modello_antenna": "ModelloAntenna",
            "tecnologia": "Tecnologia",
            "azimut": "Azimut",
            "quota_ce": "QuotaCE",
            "tilte": "Tilte",
            "tilte_min": "TilteMin",
            "tilte_max": "TilteMax",
            "tiltm": "Tiltm",
            "tiltm_min": "TiltmMin",
            "tiltm_max": "TiltmMax",
            "num_portanti_attivabili": "NumPortantiAttivabili",
            "potenza_nominale": "PotenzaNominale",
            "perdita_trasmissione": "PerditaTrasmissione",
            "potenza_totale_connettore": "PotenzaTotaleConnettore",
            "alfa24": "Alfa24", 
            "sito_rif_alfa_24": "SitoRifAlfa24",
            "alfa_pc": "AlfaPC",
            "alfa_dtx": "AlfaDTX",
            "fpr": "Fpr",
            "ftc": "Ftc",
            "potenza_irradiata_connettore": "PotenzaIrradiataConnettore",
            "eirp": "Eirp",
            "guadagno": "Guadagno",
            "polarizzazione": "Polarizzazione",
            "coordinata_x": "CoordinataX",
            "coordinata_y": "CoordinataY",
            "coordinata_z": "CoordinataZ",
            "settore": "Settore",
            "file_msi": "FileMsi"
        }

        # Converti tutti i campi in CamelCase
        result = {}
        for s, c in snake2camel.items():
            if s in d:
                # Skip empty values
                if d[s] in (None, '', 'None'):
                    continue
                    
                if s == "tecnologia" and d[s] is not None:
                    result[c] = d[s].value
                elif s == "modello_antenna":
                    result[c] = {"CodiceModelloAntenna": d[s]}
                elif s == "file_msi":
                    lst = [fm.to_dict() for fm in (self.file_msi or [])]
                    if lst:
                        result[c] = lst if len(lst) > 1 else lst[0]
                else:
                    # Use keep_zero=True for required numeric fields
                    is_required = self.__dataclass_fields__[s].metadata.get('required', False)
                    if isinstance(d[s], (int, float)):
                        from app.backend.models.pratica_model import _fmt
                        result[c] = _fmt(d[s], keep_zero=is_required)
                    else:
                        result[c] = d[s]

        # Ordina secondo lo schema XSD
        ordered_d = ordered(result, "CRELProgettoSRBType")
        
        # Rimuovi i campi vuoti ma mantieni quelli con valori di default
        return {k: v for k, v in ordered_d.items() if v is not None}

import re

def camel_to_snake(name: str) -> str:
    """
    Converti un nome da CamelCase (o PascalCase) in snake_case.
    Serve ai test per mappare i nomi dei campi del form.
    """
    s1 = re.sub(r'(.)([A-Z][a-z]+)', r'\1_\2', name)
    return re.sub(r'([a-z0-9])([A-Z])', r'\1_\2', s1).lower()
