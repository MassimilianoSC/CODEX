from dataclasses import dataclass, field
from typing import Optional, Dict, Any

@dataclass
class FileMsi:
    """
    Rappresenta un file MSI associato a un sistema.

    Corrisponde al tipo FileMsiType nello XSD, e sarà utilizzato
    sia da CRELProgettoSRB che dal modello principale.
    """
    grado_tilte: Optional[str] = field(default=None, metadata={
        'required': True,  # XSD: minOccurs > 0
    })
    nome_file_msi: str = field(default="default.msi", metadata={
        'required': True,
    })

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "FileMsi":
        """
        Converte il dict {'GradoTilte': '2', 'NomeFileMsi': 'abc.msi'}
        in un oggetto FileMsi.
        """
        nome_file = data.get("NomeFileMsi")
        if not nome_file:  # None, "" o altri valori falsy
            nome_file = "default.msi"
        elif len(nome_file) > 100:
            raise ValueError("NomeFileMsi deve essere una stringa di max 100 caratteri")
            
        return cls(
            grado_tilte=int(data.get("GradoTilte") or 0),
            nome_file_msi=nome_file
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "GradoTilte": self.grado_tilte,
            "NomeFileMsi": self.nome_file_msi or "default.msi",  # Assicura che non sia mai vuoto
        }
