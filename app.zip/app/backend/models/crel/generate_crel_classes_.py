from pathlib import Path
from app.backend.schema.loader import load_schema
from dataclasses import dataclass, field
from typing import Optional, Any

# Script per generare le classi CREL basate sullo schema XSD
HERE = Path(__file__).parent
SCHEMA = load_schema()

for type_name, td in SCHEMA.items():
    # Genera solo i tipi CREL (terminano con 'Type')
    if not type_name.endswith('Type'):
        continue

    class_name = type_name[:-4]
    lines: list[str] = []
    for f in td.fields:
        # Usa metadata per indicare i campi obbligatori
        required = 'True' if f.required else 'False'
        lines.append(
            f"    {f.name.lower()}: Optional[Any] = field(default=None, metadata={{'required': {required}}})"
        )

    # Costruisci il contenuto del file
    content = f'''from dataclasses import dataclass, field
from typing import Optional, Any
from .base import CRELBase

@dataclass
class {class_name}(CRELBase):
''' + "\n".join(lines) + "\n"

    # Scrivi il file .py corrispondente
    (HERE / f"{class_name.lower()}.py").write_text(content, encoding='utf-8')
