from dataclasses import dataclass, fields
from typing import Any, Dict
import re
#from app.backend.schema.order import ordered
from app.backend.schema.order import ordered
import collections.abc as cabc

# --------------------------------------------------------------------- #
# helper CamelCase ➜ snake_case (brevissimo, senza dipendenze esterne)  #
_CAMEL_RE_1 = re.compile(r'(.)([A-Z][a-z]+)')
_CAMEL_RE_2 = re.compile(r'([a-z0-9])([A-Z])')

def _camel_to_snake(name: str) -> str:
    s1 = _CAMEL_RE_1.sub(r'\1_\2', name)
    return _CAMEL_RE_2.sub(r'\1_\2', s1).lower()
# --------------------------------------------------------------------- #

@dataclass
class CRELBase:
    """
    Base class per tutte le classi CREL generate o manuali.
    Usa `ordered()` per produrre dict ordinati secondo lo XSD.
    """

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CRELBase":
        names = {f.name for f in fields(cls)}

        # 1. mappa CamelCase → snake_case
        snake = {_camel_to_snake(k): v for k, v in data.items()}

        # 2. aggiungi anche le chiavi originali (CamelCase)
        snake.update(data)

        # 3. passa solo quelle che la dataclass riconosce
        return cls(**{k: snake.get(k) for k in names})

    def to_dict(self) -> Dict[str, Any]:
        raw = {
            f.name: getattr(self, f.name)
            for f in fields(self)
            if getattr(self, f.name) is not None
        }
        type_name = type(self).__name__ + "Type"
        return ordered(raw, type_name)

    def is_valid(self) -> bool:
        """
        Ritorna True se – e solo se – *tutti* i campi marcati
        metadata['required']=True hanno un valore “non vuoto”.
        """
        for f in fields(self):
            if f.metadata.get("required", False):
                v = getattr(self, f.name)
                if v is None or (isinstance(v, str) and v == '') \
                or (isinstance(v, cabc.Collection) and len(v) == 0):
                    return False
        return True

