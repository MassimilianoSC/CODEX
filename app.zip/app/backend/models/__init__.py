## 1. models/__init__.py

from .pratica_model import *  # existing core models
