﻿# tools/generate_enums.py
"""
Rigenera backend/models/enums.py leggendo le enumerazioni dello XSD
⚠️  File generato: NON modificare a mano!
"""
from __future__ import annotations

import pathlib, re, xmlschema
from enum import IntEnum, StrEnum
import lxml.etree as ET      # xmlschema usa lxml internamente

from pathlib import Path
import argparse
import logging

XSD_PATH = (
    Path(__file__).resolve().parent      # .../scripts
        .parent                          # progetto root
        / "app" / "backend" / "schema"   # nuova struttura
        / "schemas" / "PraticaImpiantoCEMRL_v01.10.xsd"
)
SCHEMA = xmlschema.XMLSchema(XSD_PATH)

# ──────────────────── 2. Helpers ───────────────────
def snake(txt: str) -> str:
    """'E-Misurato'→E_MISURATO, '3G'→_3G, ecc."""
    txt = re.sub(r"\W+", "_", txt).upper()
    return "_" + txt if txt and txt[0].isdigit() else txt

def label_from_enum(e) -> str:
    """
    Restituisce l'etichetta leggibile:
    • se nel <xs:documentation> c'è testo → quello
    • altrimenti il valore raw (numerico o stringa)
    """
    if hasattr(e, "annotation") and e.annotation and e.annotation.documentation:
        return snake(e.annotation.documentation.strip())
    return snake(str(getattr(e, "value", e)))   # e può essere obj o str/int


# ──────────────────── 3. Costruisci codice ─────────
def main():
    parser = argparse.ArgumentParser(description="Genera enums.py dalle enumerazioni dello XSD")
    parser.add_argument("--xsd", default=str(XSD_PATH), help="Percorso allo XSD")
    parser.add_argument("--out", default=str(
        Path(__file__).resolve().parent.parent / "app" / "backend" / "models" / "enums.py"
    ), help="File di output enums.py")
    parser.add_argument("--loglevel", default="INFO", help="Livello di log (DEBUG, INFO, WARNING)")
    args = parser.parse_args()

    logging.basicConfig(level=getattr(logging, args.loglevel.upper(), logging.INFO))
    log = logging.getLogger("generate_enums")

    schema = xmlschema.XMLSchema(args.xsd)
    code: list[str] = [
        "from enum import IntEnum, StrEnum",
        "from app.backend.utils.enum_helpers import LabelValueMixin",
        "",
        "#  file generato automaticamente: **NON modificare a mano**\n",
    ]

    enum_count = 0
    for st in schema.types.values():
        if not (st.is_simple() and st.enumeration):
            continue
        enum_items: list[tuple[str, str | None]] = []
        for enum_node in st.elem.findall(".//{http://www.w3.org/2001/XMLSchema}enumeration"):
            val = enum_node.get("value")
            doc_node = enum_node.find("{http://www.w3.org/2001/XMLSchema}annotation/"
                                      "{http://www.w3.org/2001/XMLSchema}documentation")
            doc = doc_node.text.strip() if doc_node is not None and doc_node.text else None
            enum_items.append((val, doc))
        cls_name = snake(st.name or "ENUM")
        if all(v.isdigit() for v, _ in enum_items):
            code.append(f"class {cls_name}(IntEnum, LabelValueMixin):")
            for raw, doc in enum_items:
                label = snake(doc or raw)
                code.append(f"    {label} = {int(raw)}")
        else:
            code.append(f"class {cls_name}(StrEnum, LabelValueMixin):")
            for raw, doc in enum_items:
                label = snake(doc or raw)
                code.append(f"    {label} = {raw!r}")
        code.append("")
        enum_count += 1

    enums_py = Path(args.out)
    new_content = "\n".join(code)
    if enums_py.exists():
        old_content = enums_py.read_text(encoding="utf-8")
        if old_content == new_content:
            log.info("Nessuna modifica: enums.py già aggiornato.")
            return
    enums_py.write_text(new_content, encoding="utf-8")
    log.info("Trovate %d enumeration in %s", enum_count, args.xsd)
    log.info("✅  enums.py rigenerato → %s", enums_py)

if __name__ == "__main__":
    main()
