#!/usr/bin/env python3
"""
Entry‑point per l'applicazione web PraticaImpiantoCEMRL.
"""

from webapp import create_app

app = create_app()

def main():
    import os, logging

    # Parametri di avvio da environment, con default
    debug = os.getenv("FLASK_DEBUG", "false").lower() in ("1", "true")
    host  = os.getenv("FLASK_RUN_HOST", "127.0.0.1")
    port  = int(os.getenv("FLASK_RUN_PORT", "5000"))

    # Logging basato su app.debug
    handler = logging.StreamHandler()
    handler.setLevel(logging.DEBUG if debug else logging.INFO)
    app.logger.addHandler(handler)

    # Avvio del server
    app.run(debug=debug, host=host, port=port)

if __name__ == "__main__":
    main()
