/* ---------- utility condivise ---------- */
window.qsa = (sel, root = document) => Array.from(root.querySelectorAll(sel));

let _uid = 0;
window.uniq = () => `fld_${Date.now()}_${_uid++}`;

function resetInputs(node) {
    // svuota input, textarea, select
    node.querySelectorAll('input, textarea, select').forEach(el => {
        if (el.type === 'checkbox' || el.type === 'radio') {
            el.checked = false;
        } else {
            el.value = '';
        }
    });
}

function renumberImpianto(impDiv, impIdx) {
    impDiv.querySelectorAll('[name],[id]').forEach(el => {
        ['name', 'id'].forEach(attr => {
            if (!el[attr]) return;            // salta elementi senza name/id
            el[attr] = el[attr].replace(/^impianti_list-\d+-/, `impianti_list-${impIdx}-`);
        });
    });
}

/* --- FIX PER ID DUPLICATI (disattivato) --------------------------- */ 
window.fixDuplicateIds = () => {/* disabled - no op */};

window.showToast = function(message, type = 'info') {
    // chiudi eventuali toast ancora visibili 
    document.querySelectorAll('.toast.show').forEach(t => { 
        bootstrap.Toast.getInstance(t)?.hide(); 
    });

    // mappa custom → bootstrap 
    const map = { error: 'danger', warn: 'warning' }; 
    const btType = map[type] || type;           // info, success, danger, … 

    const target = document.getElementById('toastContainer') || document.body;
    const toast = document.createElement('div');
    toast.className = `toast align-items-center text-white bg-${btType} border-0 position-fixed top-0 end-0 m-3`;
    toast.setAttribute('role', 'alert');
    
    // Format the message using the same logic as renderLog
    const formattedMessage = typeof message === 'string' ? message :
        (message.msg || message.message || JSON.stringify(message, null, 2));
    
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">${formattedMessage}</div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    `;
    target.appendChild(toast);
    const bsToast = new bootstrap.Toast(toast);
    bsToast.show();
    toast.addEventListener('hidden.bs.toast', () => toast.remove());
};

window.debounceClick = function(btn) {
    if (btn.__onceLock) return true;
    btn.__onceLock = true;
    setTimeout(() => delete btn.__onceLock, 500);
    return false;
};

/* ------------------------------------------------------------------ 
   Visualizza i log di validazione nel riquadro giusto 
------------------------------------------------------------------ */ 
window.renderLog = function (box, out) { 
    // individua il riquadro corretto se ne è stato passato uno "qualunque" 
    if (out.stage === 'fields') 
        box = document.querySelector('#fieldResults'); 
    else if (out.stage === 'xsd') 
        box = document.querySelector('#validationResults'); 
    else if (out.stage === 'business') 
        box = document.querySelector('#businessResults'); 

    // Proteggi contro null/undefined e assicurati che errors sia un array
    const errs = Array.isArray(out.errors) ? out.errors : [];

    if (errs.length === 0) {
        box.innerHTML = '<div class="alert alert-success mb-0">✅ Nessun errore</div>';
        new bootstrap.Collapse(box.closest('.accordion-collapse'), {show: true});
        return;
    }

    // costruisci la lista
    const ul = document.createElement('ul');
    ul.className = 'mb-0';
    
    errs.forEach(e => {           // ora sicuro è un array
        const li = document.createElement('li');
        li.textContent = e.msg || e.message || JSON.stringify(e);
        ul.appendChild(li);
    });
    
    box.innerHTML = '';
    box.appendChild(ul);

    // sezione aperta in automatico 
    new bootstrap.Collapse(box.closest('.accordion-collapse'), {show: true});
};

/* === LISTENER PER I PULSANTI DI VALIDAZIONE (XSD / BUSINESS) ================ */
document.addEventListener('click', e => {
    const btn = e.target.closest('[data-endpoint]');
    if (btn) {
        console.log('[DBG-UI] click su', btn.id, '→ endpoint:', btn.dataset.endpoint);
        window.callValidator(btn);
    }
});

// Aggiorna callValidator per usare FormData
window.callValidator = async function(btn) {
    console.log('[DBG-UI] entro in callValidator per', btn.id);
    if (window.debounceClick(btn)) return;
    
    const url = btn.dataset.endpoint;
    const label = btn.textContent.trim();
    
    window.showToast(`${label} in corso…`, 'info');

    try {
        const formEl = document.getElementById('praticaForm');
        const formData = new FormData(formEl);
        
        // Clean empty fields only when saving
        if (url === '/save') {
            [...formData.keys()].forEach(k => {
                const v = formData.get(k);
                if (v === '' || v == null) formData.delete(k);
            });
        }

        const csrfToken = document.querySelector('input[name="csrf_token"]')?.value || '';
        formData.append('csrf_token', csrfToken);
        
        console.log('[DBG-UI] invio richiesta a', url);
        const res = await fetch(url, {
            method: 'POST',
            body: formData
        });
        console.log('[DBG-UI] HTTP status', res.status);
        
        const data = await res.json();
        console.log('[DBG-UI] risposta JSON:', data);
        
        // Chiudi il toast "in corso..."
        bootstrap.Toast.getInstance(document.querySelector('.toast.show'))?.hide();
        
        // Mostra il log solo se c'è uno stage (validazione) o se è un errore
        if (data.stage) {
            // La UI è ora gestita da renderErrors() in validation_ui.js
            if (data.stage === 'fields') {
                new bootstrap.Collapse(
                    document.querySelector('#collapseValidazione'),
                    { show: true }
                );
                window.showToast(
                    '⚠️  Compila i campi obbligatori (contrassegnati con l\'asterisco rosso) e riprova',
                    'error'
                );
                return;
            }
        }
        
        // Gestione esito validazione/salvataggio
        if (('ok' in data ? data.ok : data.success) === true) {
            window.showToast(data.message || '✅ Pratica salvata', 'success');
        } else {
            if (data.message && typeof data.message !== 'string') {
                console.warn('[DBG-UI] Messaggio non testuale:', data.message);
            }
            let msg = '❌ Errore generico';
            if (typeof data.message === 'string') {
                msg = data.message;
            } else if (Array.isArray(data.errors)) {
                msg = data.errors.map(e => e.msg || e.message || JSON.stringify(e)).join('\n');
            } else if (typeof data.message === 'object') {
                msg = JSON.stringify(data.message, null, 2);
            }

            window.showToast(msg, 'danger');
        }
    } catch (err) {
        console.error('[DBG-UI] errore in callValidator:', err);
        window.showToast('Errore di rete', 'error');
    }
};

document.addEventListener('DOMContentLoaded', () => {
    /* pulisce i valori e rigenera id/for per evitare duplicati */
    function clearInputs(node) {
        window.qsa('input,select,textarea', node).forEach(el => {
            if (el.id) {
                const old = el.id;
                const neo = window.uniq();
                el.id = neo;
                const lab = node.querySelector(`label[for="${old}"]`);
                if (lab) lab.htmlFor = neo;
            }
        });
    }

    /* ---------- gestione sistemi ---------- */
    function cloneSystem(template) {
        const clone = template.cloneNode(true);
        clearInputs(clone);
        resetInputs(clone);  // Reset aggiuntivo per sicurezza
        return clone;
    }

    /* ---------- gestione punti di misura ---------- */
    function clonePunto(template) {
        const clone = template.cloneNode(true);
        clearInputs(clone);
        resetInputs(clone);  // Reset aggiuntivo per sicurezza
        return clone;
    }

    /* ---------- gestione misure ---------- */
    function cloneMisura(template) {
        const clone = template.cloneNode(true);
        clearInputs(clone);
        resetInputs(clone);  // Reset aggiuntivo per sicurezza
        return clone;
    }

    /* ---------- gestione file MSI ---------- */
    function cloneFileMsi(template) {
        const clone = template.cloneNode(true);
        clearInputs(clone);
        resetInputs(clone);  // Reset aggiuntivo per sicurezza
        return clone;
    }

    /* ---------- funzioni di rinumerazione ---------- */
    function renumberSystem(sysDiv, impIdx, sysIdx) {
        console.log(`Rinumerazione Sistema: impIdx=${impIdx}, sysIdx=${sysIdx}`);

        // 1. Rinumera campi diretti del sistema e campi CREL
        window.qsa('[name],[id]', sysDiv).forEach(el => {
            // Evita di processare elementi dentro punti/misure/file qui
            if (el.closest('.punto-entry') || el.closest('.misura-entry') || el.closest('.file-entry')) {
                return;
            }
            ['name', 'id'].forEach(attr => {
                if (!el[attr]) return;
                const oldAttr = el[attr];
                // Regex per sostituire solo il blocco impianti-sistemi all'inizio
                el[attr] = oldAttr.replace(
                    /^impianti_list-\d+-sistemi-\d+/,
                    `impianti_list-${impIdx}-sistemi-${sysIdx}`
                );
            });
        });

        // 2. Rinumera i punti di misura
        window.qsa('.punto-entry', sysDiv).forEach((puntoDiv, puntoIdx) => {
            renumberPunto(puntoDiv, impIdx, sysIdx, puntoIdx);
        });
    }

    function renumberMisure(puntoEl, impIdx, sysIdx, puntoIdx) {
        const misure = puntoEl.querySelectorAll('.misura-entry');
        misure.forEach((misEl, mIdx) => {
            misEl.querySelectorAll('input, select, textarea').forEach(inp => {
                if (!inp.name) return;
                inp.name = inp.name
                    .replace(/impianti_list-\d+/,   `impianti_list-${impIdx}`)
                    .replace(/sistemi-\d+/,         `sistemi-${sysIdx}`)
                    .replace(/punti_misura-\d+/,    `punti_misura-${puntoIdx}`)
                    .replace(/misure_list-\d+/,     `misure_list-${mIdx}`);
            });
            // PATCH: aggiorna anche id se serve
            misEl.querySelectorAll('[id]').forEach(inp => {
                if (!inp.id) return;
                inp.id = inp.id
                    .replace(/impianti_list-\d+/,   `impianti_list-${impIdx}`)
                    .replace(/sistemi-\d+/,         `sistemi-${sysIdx}`)
                    .replace(/punti_misura-\d+/,    `punti_misura-${puntoIdx}`)
                    .replace(/misure_list-\d+/,     `misure_list-${mIdx}`);
            });
            renumberMisura(misEl, impIdx, sysIdx, puntoIdx, mIdx);
        });
    }

    function renumberPunto(puntoDiv, impIdx, sysIdx, puntoIdx) {
        window.qsa('[name],[id]', puntoDiv).forEach(el => {
            if (el.closest('.misura-entry')) return;
            ['name', 'id'].forEach(attr => {
                if (!el[attr]) return;
                const oldAttr = el[attr];
                el[attr] = oldAttr.replace(
                    /^impianti_list-\d+-sistemi-\d+-punti_misura-\d+/,
                    `impianti_list-${impIdx}-sistemi-${sysIdx}-punti_misura-${puntoIdx}`
                );
            });
        });
        renumberMisure(puntoDiv, impIdx, sysIdx, puntoIdx);
    }

    function renumberMisura(misuraDiv, impIdx, sysIdx, puntoIdx, misuraIdx) {
        window.qsa('[name],[id]', misuraDiv).forEach(el => {
            ['name', 'id'].forEach(attr => {
                if (!el[attr]) return;
                el[attr] = el[attr].replace(
                    /^impianti_list-\d+-(?:sistemi-\d+-)?punti_misura-\d+-misure_list-\d+/,
                    `impianti_list-${impIdx}-sistemi-${sysIdx}-punti_misura-${puntoIdx}-misure_list-${misuraIdx}`
                );
            });
        });
    }

    function renumberFileMsi(fileDiv, impIdx, sysIdx, fileIdx) {
        console.log(`Rinumerazione File MSI: impIdx=${impIdx}, sysIdx=${sysIdx}, fileIdx=${fileIdx}`);

        window.qsa('[name],[id]', fileDiv).forEach(el => {
            ['name', 'id'].forEach(attr => {
                if (!el[attr]) return;
                const oldAttr = el[attr];
                el[attr] = oldAttr.replace(
                    /^impianti_list-\d+-sistemi-\d+-crel_progetto-file_msi-\d+/,
                    `impianti_list-${impIdx}-sistemi-${sysIdx}-crel_progetto-file_msi-${fileIdx}`
                );
            });
        });
    }

    // --- PATCH: rinumerazione continua punti di misura ---
    function renumberAllPunti(container, impIdx, sysIdx) {
        window.qsa('.punto-entry', container).forEach((puntoDiv, puntoIdx) => {
            renumberPunto(puntoDiv, impIdx, sysIdx, puntoIdx);
        });
    }

    /* ---------- handlers ---------- */
    function handleClick(e) {
        const btn = e.target.closest('button');
        if (!btn || window.debounceClick(btn)) return;

        if (btn.classList.contains('addSystem')) {
            const impIdx   = btn.dataset.imp;
            const sysBox   = document.getElementById(`systems-${impIdx}`);
            const sysTpl   = sysBox.querySelector('.system-entry');
            if (!sysTpl) return;

            const newIdx   = sysBox.querySelectorAll('.system-entry').length;
            const newSys   = cloneSystem(sysTpl);
            
            // Svuota i campi del sistema clonato
            newSys.querySelectorAll('input, select, textarea').forEach(el => {
                if (el.type !== 'checkbox' && el.type !== 'radio') {
                    el.value = '';
                }
            });

            renumberSystem(newSys, impIdx, newIdx);

            // PATCH: usa il contenitore globale dei punti di misura
            const puntiCont = document.getElementById(`punti-${impIdx}`);
            // NON svuotare più il contenitore globale
            // puntiCont.innerHTML = '';

            const templatePunto  = document.querySelector('.punto-entry');
            const newPunto  = clonePunto(templatePunto);
            
            newPunto.querySelectorAll('input, select, textarea').forEach(el => {
                if (el.type !== 'checkbox' && el.type !== 'radio') {
                    el.value = '';
                }
            });

            const misContainer = newPunto.querySelector('.misure-container');
            if (misContainer) {
                const misTpl = misContainer.querySelector('.misura-entry');
                misContainer.innerHTML = '';
                const newMis = cloneMisura(misTpl);
                
                newMis.querySelectorAll('input, select, textarea').forEach(el => {
                    if (el.type !== 'checkbox' && el.type !== 'radio') {
                        el.value = '';
                    }
                });
                
                misContainer.appendChild(newMis);
            }
            const nextPuntoIdx = puntiCont.querySelectorAll('.punto-entry').length;
            renumberPunto(newPunto, impIdx, newIdx, nextPuntoIdx);
            puntiCont.appendChild(newPunto);

            sysBox.appendChild(newSys);
            refreshRemoveButtons();
            updateNumbers();
        }
        else if (btn.classList.contains('addPuntoMisura')) {
            const impIdx = btn.dataset.imp;
            const container = document.getElementById(`punti-${impIdx}`);
            const template = container.querySelector('.punto-entry');
            if (template) {
                const clone = clonePunto(template);
                container.appendChild(clone);
                // Rinumeriamo TUTTI i punti dopo l'aggiunta!
                renumberAllPunti(container, impIdx, 0); // usa 0 o il sysIdx corretto se serve
                refreshRemoveButtons();
                updateNumbers();
            }
        }
        else if (btn.classList.contains('addMisura')) {
            const puntoDiv = btn.closest('.punto-entry');
            const impIdx = puntoDiv.closest('.punti-container').id.split('-')[1];
            const container = puntoDiv.querySelector('.misure-container');
            const template = container.querySelector('.misura-entry');
            if (template) {
                const clone = cloneMisura(template);
                const newIdx = container.querySelectorAll('.misura-entry').length;
                const puntoIdx = [...puntoDiv.parentElement.children].indexOf(puntoDiv);
                renumberMisura(clone, impIdx, 0, puntoIdx, newIdx); // 0 se hai un solo sistema
                container.appendChild(clone);
                refreshRemoveButtons();
                updateNumbers();
            }
        }
        else if (btn.classList.contains('addFileMsi')) {
            const sysDiv = btn.closest('.system-entry');
            const impIdx = sysDiv.closest('.systems-container').id.split('-')[1];
            const sysIdx = sysDiv.dataset.sys;
            const container = sysDiv.querySelector('.filemsi-container');
            const template = container.querySelector('.filemsi-entry');
            if (template) {
                const clone = cloneFileMsi(template);
                const newIdx = container.querySelectorAll('.filemsi-entry').length;
                renumberFileMsi(clone, impIdx, sysIdx, newIdx);
                container.appendChild(clone);
                refreshRemoveButtons();
            }
        }
        else if (btn.classList.contains('removeSystem')) {
            const entry = btn.closest('.system-entry');
            if (entry) {
                entry.remove();
                refreshRemoveButtons();
                updateNumbers();
            }
        }
        else if (btn.classList.contains('removePuntoMisura')) {
            const entry = btn.closest('.punto-entry');
            if (entry) {
                const container = entry.parentElement;
                entry.remove();
                // Rinumeriamo TUTTI i punti dopo la rimozione!
                const impIdx = btn.dataset.imp || 0;
                renumberAllPunti(container, impIdx, 0); // usa 0 o il sysIdx corretto se serve
                refreshRemoveButtons();
                updateNumbers();
            }
        }
        else if (btn.classList.contains('removeMisura')) {
            const entry = btn.closest('.misura-entry');
            if (entry) {
                entry.remove();
                refreshRemoveButtons();
                updateNumbers();
            }
        }
        else if (btn.classList.contains('removeFileMsi')) {
            const entry = btn.closest('.filemsi-entry');
            if (entry) {
                entry.remove();
                refreshRemoveButtons();
            }
        }
        else if (btn.classList.contains('addImpianto')) {
            const container = document.querySelector('.impianti-container');
            const template = container.querySelector('.impianto-entry');
            if (template) {
                const clone = template.cloneNode(true);
                const newIdx = container.querySelectorAll('.impianto-entry').length;
                renumberImpianto(clone, newIdx);
                container.appendChild(clone);
                refreshRemoveButtons();
                updateNumbers();
            }
        }
        else if (btn.classList.contains('removeImpianto')) {
            const entry = btn.closest('.impianto-entry');
            if (entry) {
                entry.remove();
                document.querySelectorAll('.impianto-entry').forEach((div, idx) => {
                    renumberImpianto(div, idx);
                });
                refreshRemoveButtons();
                updateNumbers();
            }
        }
    }

    /* ---------- gestione numerazione ---------- */
    function updateNumbers() {
        // Rinumerazione Sistemi
        document.querySelectorAll('.systems-container').forEach(container => {
            container.querySelectorAll('.system-entry').forEach((sys, i) => {
                renumberSystem(sys, 0, i);                    // ★ ripristinato
                sys.querySelector('h6').textContent = `Sistema #${i + 1}`;
            });
        });

        // Punti di misura – rinumerazione locale per ogni sistema
        document.querySelectorAll('.punti-container').forEach(pCont => {
            pCont.querySelectorAll('.punto-entry').forEach((punto, idx) => {
                punto.querySelector('h6').textContent = `Punto #${idx + 1}`;
            });
        });
        document.querySelectorAll('.misura-entry').forEach((misura, i) => {
            misura.querySelector('h6').textContent = `Misura #${i + 1}`;
        });
        document.querySelectorAll('.filemsi-entry').forEach((file, i) => {
            file.querySelector('h6').textContent = `File MSI #${i + 1}`;
        });
    }

    /* ---------- gestione pulsanti rimozione ---------- */
    function refreshRemoveButtons() {
        document.querySelectorAll('.systems-container').forEach(container => {
            const systems = container.querySelectorAll('.system-entry');
            systems.forEach(sys => {
                const btn = sys.querySelector('.removeSystem');
                btn.disabled = systems.length <= 1;
            });
        });

        document.querySelectorAll('.punti-container').forEach(container => {
            const punti = container.querySelectorAll('.punto-entry');
            punti.forEach(punto => {
                const btn = punto.querySelector('.removePuntoMisura');
                btn.disabled = punti.length <= 1;
            });
        });

        document.querySelectorAll('.misure-container').forEach(container => {
            const misure = container.querySelectorAll('.misura-entry');
            misure.forEach(misura => {
                const btn = misura.querySelector('.removeMisura');
                btn.disabled = misure.length <= 1;
            });
        });
    }

    /* ---------- inizializzazione ---------- */
    // fixDuplicateIds();   // disattivato: causa lag sui form grandi
    document.addEventListener('click', handleClick);
    refreshRemoveButtons();
    updateNumbers();
});