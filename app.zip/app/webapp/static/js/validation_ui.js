// Rende gli errori XSD in modo più leggibile
export function renderErrors(selector, errors) {
  const box = document.querySelector(selector);
  if (!box) return;

  if (!errors || errors.length === 0) {
    box.innerHTML =
      '<div class="alert alert-success mb-0">Nessun errore: XML conforme.</div>';
    return;
  }

  let html = '<ul class="list-group">';
  for (const err of errors) {
    const msg = err.msg || err;               // fallback se è stringa grezza
    html += `<li class="list-group-item list-group-item-danger">
               <i class="fas fa-exclamation-triangle me-2"></i>${msg}
             </li>`;
  }
  html += '</ul>';
  box.innerHTML = html;
} 