from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, get_origin, get_args, Union
import re
import json
from wtforms import FieldList
from dataclasses import is_dataclass, asdict, fields
import logging
import os
from werkzeug.datastructures import MultiDict
from flask import session
from app.backend.models.utils import _safe_enum
from enum import Enum, IntEnum
from app.backend.models import enums
from app.backend.models.enums import TECNOLOGIATYPE
from webapp.forms import PraticaForm
from app.backend.utils import xml_parser
from app.backend.utils.xml_parser import load as _load_xml, save as _save_xml
from app.backend.validators.xml_validator import XMLValidator as _XMLValidator
from app.backend.models.pratica_model import (
    PraticaImpiantoCEMRL,
    Impianto,
    Sistema,
    TipoPratica,
    ModelloAntenna,
    FileMsi,
    _blank_crel,
    PuntoMisura,
    Misura,
)
from app.backend.models.crel.crelprogettosrb import CRELProgettoSRB
from app.backend.models.crel.filemsi import FileMsi

def _get_field(form, name, default=None):
    """
    Helper per estrarre un valore da form, sia esso un MultiDict (request.form)
    o un oggetto WTForms.
    """
    # MultiDict (request.form) o dict puro
    if hasattr(form, "get"):
        return form.get(name, default)
    # Oggetto WTForms – cerca un campo con quel nome
    fld = getattr(form, name, None)
    return fld.data if fld is not None else default

# Add the enum mapping dictionary
_ENUM_MAP = {
    'tecnologia': enums.Tecnologia,  # alias a TECNOLOGIATYPE
    'tipo_misura': enums.TipoMisura,
    'pmc': enums.PMC,
}

def _clean_zero(value):
    """Converte valori '0' o '0.0' in None."""
    if value is None:
        return None
    str_val = str(value).strip()
    if str_val in ('0', '0.0', '0,0'):
        print(f"[DEBUG] Converting zero value to None: {value!r}")
        return None
    return value

def _copy_fields_from_form(form_obj, model_obj, skip_lists: bool = False):
    """
    Copia ogni attributo dal `form_obj` al `model_obj`.
    Se il campo nel dataclass è un Enum, converte la stringa
    in istanza Enum tramite _safe_enum().
    """
    for f in fields(model_obj):
        if skip_lists and isinstance(getattr(model_obj, f.name), list):
            continue
        if not hasattr(form_obj, f.name):
            continue

        value = getattr(form_obj, f.name).data
        print("DBG raw", f.name, "=", value)  # Debug richiesto

        # Se il valore che arriva dal form è vuoto e il modello aveva già un valore,
        # NON sovrascrivere
        if value in ('', None) and getattr(model_obj, f.name, None) not in ('', None):
            continue

        # Normalizza valori vuoti a None
        if value in ("", "None"):
            value = None

        # ---------- rileva l'enum in modo affidabile ----------
        enum_cls = None

        # (a) se l'attributo attuale è già un Enum (default del dataclass)
        current = getattr(model_obj, f.name, None)
        if isinstance(current, Enum):
            enum_cls = type(current)

        # (b) annotation diretta:   tecnologia: TECNOLOGIATYPE
        elif isinstance(f.type, type) and issubclass(f.type, Enum):
            enum_cls = f.type

        # (c) annotation Union / "|" :  TECNOLOGIATYPE | None
        else:
            for arg in get_args(f.type) or ():
                if isinstance(arg, type) and issubclass(arg, Enum):
                    enum_cls = arg
                    break

        # --- gestione campi enum ------------------------------------------
        if enum_cls is not None:
            raw = value
            # Se il valore proveniente dal form è ''/None non sovrascrivere il default
            if raw in ('', 'None', None):
                continue  # salta setattr, il default resta
            try:
                raw_int = int(raw)
            except ValueError:
                raw_int = raw  # codice alfanumerico (es. "P9")
            value = enum_cls(raw_int)  # senza default: se non valido, ValueError

        # OraMisura: se vuoto ⇒ None
        if f.name == "ora_misura" and value in ("", "0", None):
            value = None

        setattr(model_obj, f.name, value)

log = logging.getLogger(__name__)          # ✨ 1

# --- Utility Functions ---
def _to_form_value(v):
    if v is None:
        return None
    if hasattr(v, "value"):
        return str(v.value)
    if isinstance(v, int):
        return str(v)
    return v

def _clean_placeholder(v):
    """Rende vuoti i placeholder usati solo per aggirare minOccurs."""
    if v in ("TBD", "IMP-1"):
        return ""          # stringhe
    return v

def safe_set(form_field, value):
    print("DEBUG SAFE_SET:", value, type(value))
    if hasattr(form_field, "data"):
        if value is not None:
            form_field.data = _to_form_value(value)
        else:
            form_field.data = ''  # Per SelectField resta sulla voce '—'

# --- Core Models ---
from app.backend.models.pratica_model import (
    PraticaImpiantoCEMRL,
    Impianto,
    Sistema,
    TipoPratica,
    ModelloAntenna,
    FileMsi,
    _blank_crel,
    PuntoMisura,
    Misura,
)
from app.backend.models.crel.crelprogettosrb import CRELProgettoSRB
from app.backend.models.crel.filemsi import FileMsi

# --- Snake to CamelCase ---
_CAMEL_RE = re.compile(r"_([a-z])")

def _camel_from_snake(name: str) -> str:
    special_cases = {
        "quota_ce": "QuotaCE",
        "alfa24_max": "Alfa24Max",
        "alfa24_day": "Alfa24Day",
    }
    if name in special_cases:
        return special_cases[name]
    s = _CAMEL_RE.sub(lambda m: m.group(1).upper(), name)
    return s[0].upper() + s[1:]

# --- XSD Path and Loaders ---
XSD_PATH = Path(__file__).resolve().parent.parent / "backend" / "schema" / "schemas" / "PraticaImpiantoCEMRL_v01.10.xsd"

from app.backend.utils.xml_parser import load as _load_xml, save as _save_xml
from app.backend.validators.xml_validator import XMLValidator as _XMLValidator

def open_xml(xml_path: str) -> Dict[str, Any]:
    # ----------------------------------------------------------------- 
    # Controllo XSD rapido: ci fermiamo al 1° errore, niente lista 
    from app.backend.utils.xml_parser import _SCHEMA 
    non_conforme = False 
    try: 
        next(_SCHEMA.iter_errors(str(xml_path)))   # Stop al 1° errore 
        non_conforme = True 
    except StopIteration: 
        pass            # XML perfettamente valido 
    except Exception as exc: 
        log.warning("Quick-check XSD fallito: %s", exc) 
        non_conforme = True         # prudenziale 
    
    if non_conforme: 
        log.info("XML non conforme — lo carico comunque (dettagli su richiesta)") 
    # ----------------------------------------------------------------- 
    model = _load_xml(xml_path)
    return model.to_dict()

def save_xml(pratica_dict: Dict[str, Any], xml_path: str | Path, *, validate: bool = True) -> list:
    xml_path = Path(xml_path)
    xml_path.parent.mkdir(parents=True, exist_ok=True)
    pratica = PraticaImpiantoCEMRL.from_dict(pratica_dict)
    _save_xml(pratica, xml_path)
    post_errs = _XMLValidator(str(XSD_PATH)).validate(xml_path)
    return post_errs

def get_schema():
    from xmlschema import XMLSchema
    return XMLSchema(str(XSD_PATH))

def validate_xml(xml_path: str) -> List[Dict[str, Any]]:
    tree = load_tree(xml_path)
    return validate_tree(tree)

def validate_xml_file(xml_path: str) -> List[str]:
    """
    Valida direttamente un file XML contro lo schema.
    Ritorna lista di errori (vuota se valido).
    """
    from app.backend.utils.xml_parser import validate_xml
    return validate_xml(xml_path)

# --- Factory ---
def create_new_pratica() -> Dict[str, Any]:
    # campi minimi richiesti dallo XSD ─ diamo valori vuoti modificabili dall'utente
    impianto_base = Impianto.from_dict({
        "CodiceGestore": "",
        "Descrizione": "",
        "RagioneSociale": "", 
        "IdentificativoImpianto": "",
    })

    pratica = PraticaImpiantoCEMRL(
        tipo_pratica=TipoPratica.AIE,
        impianti=[impianto_base],
    )
    return pratica.to_dict()

# --- Update pratica from form ---
def update_pratica_from_form(pratica_dict: Dict[str, Any], form) -> Dict[str, Any]:
    print("🔍 DEBUG_PRATICA: Inizio update_pratica_from_form")
    print("🔍 DEBUG_PRATICA: Form ricevuto:", form)

    pratica = PraticaImpiantoCEMRL.from_dict(pratica_dict)

    # ----- header pratica ------------------------------------------------
    if form.tipo_pratica.data:
        pratica.tipo_pratica = TipoPratica(int(form.tipo_pratica.data))
    pratica.note_pratica = form.note_pratica.data

    # ----- almeno un impianto -------------------------------------------
    if not pratica.impianti:
        pratica.impianti = [Impianto.from_dict({})]
    imp = pratica.impianti[0]
    imp_form = form.impianti_list[0]

    print("🔍 DEBUG_PRATICA: Numero punti nel form:", len(imp_form.punti_misura))
    for idx, p_form in enumerate(imp_form.punti_misura):
        print(f"🔍 DEBUG_PRATICA: Punto {idx} nel form:")
        print(f"  🔍 DEBUG_PRATICA: codifica_gestore = {p_form.codifica_gestore.data}")
        print(f"  🔍 DEBUG_PRATICA: descrizione_punto = {p_form.descrizione_punto.data}")
        print(f"  🔍 DEBUG_PRATICA: coordinata_x = {p_form.coordinata_x.data}")
        print(f"  🔍 DEBUG_PRATICA: coordinata_y = {p_form.coordinata_y.data}")
        print(f"  🔍 DEBUG_PRATICA: quota = {p_form.quota.data}")
        print(f"  🔍 DEBUG_PRATICA: distanza = {p_form.distanza.data}")
        print(f"  🔍 DEBUG_PRATICA: direzione = {p_form.direzione.data}")
        print(f"  🔍 DEBUG_PRATICA: dislivello = {p_form.dislivello.data}")
        print(f"  🔍 DEBUG_PRATICA: limite_esposizione = {p_form.limite_esposizione.data}")
        print(f"  🔍 DEBUG_PRATICA: fattore_attenuazione = {p_form.fattore_attenuazione.data}")
        print(f"  🔍 DEBUG_PRATICA: note_fattore_attenuazione = {p_form.note_fattore_attenuazione.data}")
        print(f"  🔍 DEBUG_PRATICA: Numero misure nel punto {idx}: {len(p_form.misure_list)}")

    # --- Copia automatica di tutti gli attributi dell'Impianto ---
    _copy_fields_from_form(imp_form, imp, skip_lists=True)  # salta ''/None

    # ---------- Punti di misura e Misure ---------------------------------
    # Creiamo una lista temporanea per i nuovi punti
    new_punti = []
    print("🔍 DEBUG_PRATICA: Inizio processamento punti di misura")
    
    for p_form in imp_form.punti_misura:
        print(f"🔍 DEBUG_PRATICA: Processo punto con codifica_gestore = {p_form.codifica_gestore.data}")
        p = PuntoMisura()
        fields_punto = [
            "codifica_gestore",
            "descrizione_punto",
            "coordinata_x", "coordinata_y",
            "quota", "distanza", "direzione",
            "dislivello", "limite_esposizione",
            "fattore_attenuazione", "note_fattore_attenuazione"
        ]
        for field in fields_punto:
            if hasattr(p_form, field) and hasattr(p, field):
                value = getattr(p_form, field).data
                print(f"  🔍 DEBUG_PRATICA: Imposto {field} = {value}")
                setattr(p, field, value)

        # Misure del punto
        p.misure.clear()
        print(f"🔍 DEBUG_PRATICA: Processo misure per punto {p_form.codifica_gestore.data}")
        for m_idx, m_form in enumerate(p_form.misure_list):
            print(f"  🔍 DEBUG_PRATICA: Misura con tipo_misura = {m_form.tipo_misura.data}")
            # Se tutti i campi chiave sono vuoti, salta la riga fantasma
            if not m_form.tipo_misura.data and not m_form.valore_misurato.data:
                print("  🔍 DEBUG_PRATICA: Salto misura vuota")
                continue

            m = Misura()
            _copy_fields_from_form(m_form, m)
            print(f"  🔍 DEBUG_PRATICA: Aggiunta misura con tipo_misura = {m.tipo_misura}")
            print("[SONDA_C] MODEL just before save:", m_idx, m.tecnologia)

            # Cast sicuro da stringa → TECNOLOGIATYPE
            if isinstance(m.tecnologia, str):
                if m.tecnologia in (None, '', 'None'):
                    m.tecnologia = None
                else:
                    m.tecnologia = TECNOLOGIATYPE(int(m.tecnologia))

            p.misure.append(m)

        new_punti.append(p)
        print(f"🔍 DEBUG_PRATICA: Aggiunto punto {p.codifica_gestore} con {len(p.misure)} misure")

    # Sostituiamo la lista dei punti solo dopo aver processato tutto
    imp.punti_misura = new_punti
    print(f"🔍 DEBUG_PRATICA: Fine processamento punti. Totale punti: {len(imp.punti_misura)}")
    for idx, p in enumerate(imp.punti_misura):
        print(f"🔍 DEBUG_PRATICA: Punto finale {idx}:")
        print(f"  🔍 DEBUG_PRATICA: codifica_gestore = {p.codifica_gestore}")
        print(f"  🔍 DEBUG_PRATICA: numero misure = {len(p.misure)}")

    # ----- sistemi + crel + file_msi ------------------------------------
    while len(imp.sistemi) < len(imp_form.sistemi):
        imp.sistemi.append(Sistema())

    for idx, sys_form in enumerate(imp_form.sistemi):
        sistema = imp.sistemi[idx]
        _copy_fields_from_form(sys_form, sistema)

        crel = _blank_crel()
        _copy_fields_from_form(sys_form.crel_progetto, crel)

        crel.file_msi.clear()
        for f_form in sys_form.crel_progetto.file_msi:
            f_model = FileMsi()
            _copy_fields_from_form(f_form, f_model)
            crel.file_msi.append(f_model)

        sistema.crel_progetto = crel

    pratica.impianti[0] = imp
    print("🔍 DEBUG_PRATICA: Fine update_pratica_from_form")
    return pratica.to_dict()

# --- Populate form from pratica ---
def populate_form_from_pratica(form, pratica_dict: Dict[str, Any]) -> None:
    from app.backend.models.pratica_model import PraticaImpiantoCEMRL
    import logging

    logger = logging.getLogger(__name__)
    pratica = PraticaImpiantoCEMRL.from_dict(pratica_dict)

    form.tipo_pratica.data = str(pratica.tipo_pratica.value)
    form.note_pratica.data = pratica.note_pratica

    if not pratica.impianti:
        return

    imp = pratica.impianti[0]
    while len(form.impianti_list.entries) < 1:
        form.impianti_list.append_entry()
    imp_form = form.impianti_list.entries[0]

    # --- Impianto campi semplici
    fields = [
        "codice_gestore", "descrizione", "ragione_sociale", "identificativo_impianto",
        "data_inizio_gestione", "proto_concessione_ministeriale", "cod_prov", "cod_com",
        "indirizzo_localita", "coordinata_x", "coordinata_y", "quota_base",
        "note_impianto", "referente"
    ]
    for field in fields:
        if hasattr(imp_form, field) and hasattr(imp, field):
            raw = getattr(imp, field)
            value = _clean_placeholder(raw)
            safe_set(getattr(imp_form, field), value)

    # --- Sistemi
    while len(imp_form.sistemi.entries) < len(imp.sistemi):
        imp_form.sistemi.append_entry()

    for sistema_model, sistema_form in zip(imp.sistemi, imp_form.sistemi.entries):
        safe_set(sistema_form.identificativo_sistema, _clean_placeholder(sistema_model.identificativo_sistema))
        safe_set(sistema_form.sistema_attivo, sistema_model.sistema_attivo)

        crel_model = sistema_model.crel_progetto
        crel_form = sistema_form.crel_progetto

        for field_name in crel_form._fields:
            if field_name in ("csrf_token", "file_msi"):
                continue
            if hasattr(crel_model, field_name):
                value = getattr(crel_model, field_name)
                if field_name == "tecnologia":
                    value = str(value.value) if value is not None else None
                safe_set(getattr(crel_form, field_name), _clean_placeholder(value))

        # File MSI
        while len(crel_form.file_msi.entries) < len(crel_model.file_msi):
            crel_form.file_msi.append_entry()
        for f_model, f_form in zip(crel_model.file_msi, crel_form.file_msi.entries):
            safe_set(f_form.grado_tilte, _clean_placeholder(f_model.grado_tilte))
            safe_set(f_form.nome_file_msi, _clean_placeholder(f_model.nome_file_msi))

    # --- Punti di Misura
    while len(imp_form.punti_misura.entries) < len(imp.punti_misura):
        imp_form.punti_misura.append_entry()

    for punto_model, punto_form in zip(imp.punti_misura, imp_form.punti_misura.entries):
        fields_punto = [
            "codifica_gestore",
            "descrizione_punto",
            "coordinata_x", "coordinata_y",
            "quota", "distanza", "direzione",
            "dislivello", "limite_esposizione",
            "fattore_attenuazione", "note_fattore_attenuazione"
        ]
        for field in fields_punto:
            if hasattr(punto_form, field) and hasattr(punto_model, field):
                value = getattr(punto_model, field)
                safe_set(getattr(punto_form, field), _clean_placeholder(value))

        # --- Misure
        while len(punto_form.misure_list.entries) < len(punto_model.misure):
            punto_form.misure_list.append_entry()

        for m_idx, (misura_model, misura_form) in enumerate(zip(punto_model.misure, punto_form.misure_list.entries)):
            fields_misura = [
                "tipo_misura", "data_misura", "ora_misura",
                "pmc", "unita_misura", "valore_misurato",
                "tecnologia", "settore", "canale",
                "frequenza_min", "frequenza_max", "alfa_pc",
                "alfa_dtx", "rho", "nrs", "bf",
                "alfa24_max", "alfa24_day", "note_misura"
            ]
            for field in fields_misura:
                if hasattr(misura_form, field) and hasattr(misura_model, field):
                    value = getattr(misura_model, field)
                    if field == "tecnologia":
                        if value is not None:
                            value = str(value.value if hasattr(value, "value") else value)
                        else:
                            value = ''
                        safe_set(getattr(misura_form, field), _clean_placeholder(value))
                        print("DEBUG choices tecnologia:", [v for v, _ in misura_form.tecnologia.choices][:10], "…")
                        print("DEBUG data tecnologia   :", misura_form.tecnologia.data)
                    else:
                        safe_set(getattr(misura_form, field), _clean_placeholder(value))
            print("[SONDA_B] WTForms bind:", m_idx, misura_form.tecnologia.data)

# --- Business rules ---
def run_business_validation(pratica_data: Dict[str, Any] | PraticaImpiantoCEMRL) -> List[str]:
    if isinstance(pratica_data, dict):
        pratica = PraticaImpiantoCEMRL.from_dict(pratica_data)
    else:
        pratica = pratica_data

    errors: List[str] = []

    if not pratica.impianti:
        errors.append("Deve essere presente almeno un impianto.")
        return errors

    for idx, imp in enumerate(pratica.impianti, start=1):
        try:
            if float(imp.quota_base or 0) <= 0:
                errors.append(f"Quota base impianto #{idx} deve essere > 0")
        except ValueError:
            errors.append(f"Quota base impianto #{idx} non numerica")

        if not imp.punti_misura:
            errors.append(f"L'impianto #{idx} non ha punti di misura.")
            continue

        for p_idx, p in enumerate(imp.punti_misura, start=1):
            if not p.misure:
                errors.append(f"Punto #{p_idx} impianto #{idx} senza misure.")

    return errors

# --- NUOVA FUNZIONE --------------------------------------------------
def build_xml_from_form(form_data: MultiDict) -> str:
    """
    Costruisce l'XML a partire dai dati del form.
    Se c'è un XML originale nella sessione, lo usa come base per il merge.
    """
    from flask import session
    
    # Carica l'XML originale dalla sessione
    raw_xml = session.get('current_xml')
    if raw_xml:
        try:
            pratica = _load_xml(raw_xml)
            pratica_dict = pratica.to_dict()
        except Exception as e:
            log.error(f"Errore nel caricamento dell'XML originale: {e}", exc_info=True)
            pratica_dict = create_new_pratica()
    else:
        pratica_dict = create_new_pratica()

    # Crea il form e aggiorna la pratica
    form = PraticaForm(MultiDict(form_data))
    pratica_dict = update_pratica_from_form(pratica_dict, form)

    # Ordina il dict secondo l'ordine XSD
    from app.backend.utils.fixer_order import ordered
    ordered_dict = ordered(pratica_dict, "PraticaImpiantoCEMRLType")

    # Genera l'XML come stringa (senza salvare su disco)
    return xml_parser.save(PraticaImpiantoCEMRL.from_dict(ordered_dict), None)

# --- campi punto misura ---
fields_punto = [
    "codifica_gestore",
    "descrizione_punto",
    "coordinata_x", "coordinata_y",
    "quota", "distanza", "direzione",
    "dislivello", "limite_esposizione",
    "fattore_attenuazione", "note_fattore_attenuazione"
]

# --- campi punto misura (solo lettura) ---
fields_punto_readonly = [
    "codifica_gestore",
    "descrizione_punto",
    "coordinata_x", "coordinata_y",
    "quota", "distanza", "direzione",
    "dislivello", "limite_esposizione",
    "fattore_attenuazione", "note_fattore_attenuazione"
]
