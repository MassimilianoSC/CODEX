from flask_wtf import FlaskForm
from wtforms import StringField, FloatField, IntegerField, SelectField, FieldList, FormField, SubmitField
from wtforms.validators import DataRequired, Optional
from app.backend.models.enums import TIPOANTENNATYPE, TECNOLOGIATYPE, SINOTYPE, PMCTYPE, UNITAMISURATYPE, POLARIZZAZIONETYPE
from app.backend.models.crel.filemsi import FileMsi

class FileMsiForm(FlaskForm): 
    grado_tilte = FloatField("Grado Tilte", validators=[DataRequired()]) 
    nome_file_msi = StringField("Nome File MSI", validators=[DataRequired()]) 

class CRELProgettoSRBForm(FlaskForm): 
    tipo_antenna = SelectField( 
        "Tipo Antenna", 
        choices=[(t.value, t.name) for t in TIPOANTENNATYPE], 
        coerce=int, 
        validators=[DataRequired()] 
    ) 
    modello_antenna = IntegerField(
        "Modello antenna",
        validators=[DataRequired()]
    ) 
    tecnologia = SelectField(
        "Tecnologia",
        choices=[(str(t.value), t.name) for t in TECNOLOGIATYPE],
        coerce=str
    )
    settore = StringField("Settore", validators=[Optional()]) 
    azimut = FloatField("Azimut", validators=[DataRequired()]) 
    quota_ce = FloatField("Quota CE", validators=[DataRequired()]) 
    tilte = FloatField("Tilte", validators=[DataRequired()]) 
    tilte_min = FloatField("Tilte Min", validators=[DataRequired()]) 
    tilte_max = FloatField("Tilte Max", validators=[DataRequired()]) 
    tiltm = FloatField("TiltM", validators=[DataRequired()]) 
    tiltm_min = FloatField("TiltM Min", validators=[DataRequired()]) 
    tiltm_max = FloatField("TiltM Max", validators=[DataRequired()]) 
    num_portanti_attivabili = IntegerField("Numero Portanti Attivabili", validators=[DataRequired()]) 
    potenza_totale_connettore = FloatField("Potenza Totale Connettore", validators=[DataRequired()]) 
    alfa24 = FloatField("Alfa24", validators=[DataRequired()]) 
    alfa_pc = FloatField("Alfa PC", validators=[DataRequired()]) 
    alfa_dtx = FloatField("Alfa DTX", validators=[DataRequired()]) 
    eirp = FloatField("EIRP", validators=[DataRequired()]) 
    guadagno = FloatField("Guadagno", validators=[DataRequired()]) 
    file_msi = FieldList(FormField(FileMsiForm), min_entries=1, validators=[DataRequired()])
    
    # Campi opzionali
    potenza_nominale = FloatField("Potenza Nominale", validators=[Optional()])
    perdita_trasmissione = FloatField("Perdita Trasmissione", validators=[Optional()])
    fpr = FloatField("FPR", validators=[Optional()])
    ftc = FloatField("FTC", validators=[Optional()])
    potenza_irradiata_connettore = FloatField("Potenza Irradiata Connettore", validators=[Optional()])
    polarizzazione = SelectField(
        "Polarizzazione",
        choices=[('', '—')] + [(str(p.value), p.name) for p in POLARIZZAZIONETYPE],
        validate_choice=False,
        validators=[Optional()]
    )
    coordinata_x = IntegerField("Coordinata X", validators=[Optional()])
    coordinata_y = IntegerField("Coordinata Y", validators=[Optional()])
    coordinata_z = FloatField("Coordinata Z", validators=[Optional()])
    sito_rif_alfa_24 = StringField("Sito Rif. Alfa24", validators=[Optional()])

class SistemaForm(FlaskForm):
    """
    Form per un singolo sistema, con CRELProgettoSRB integrato.
    """
    identificativo_sistema = StringField(
        "Identificativo Sistema",
        validators=[DataRequired()]
    )
    sistema_attivo = SelectField(
        "Sistema Attivo",
        choices=[(str(s.value), s.name) for s in SINOTYPE],
        coerce=str,
        validators=[DataRequired()]
    )
    crel_progetto = FormField(CRELProgettoSRBForm)
