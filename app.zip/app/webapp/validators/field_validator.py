import json, re, pathlib
from flask import current_app
from functools import lru_cache
import logging
from typing import Dict, List, Any, Set
from pathlib import Path

log = logging.getLogger(__name__)

_CAMEL_RE = re.compile(r"_([a-z])")

_ALIASES = { "modello_antenna": "codice_modello_antenna" }

# Map HTML form segments to their XSD types
_TYPE_ALIAS = {
    # ― alias "storici" ―
    "crel_progetto_srb": "CRELProgettoSRBType",
    "crel_progetto":     "CRELProgettoSRBType",
    "crelprogetto":      "CRELProgettoSRBType",
    "misure_list":       "MisuraType",
    "sistemi":           "SistemaType",
    "punti_misura":      "PuntoMisuraType",
    "impianti_list":     "ImpiantoType",
    "file_msi":          "FileMsiType",

    # ― nuovi alias senza underscore / con _list ―
    "crelprogettosrb":        "CRELProgettoSRBType",
    "crelprogettosrb_list":   "CRELProgettoSRBType",
    "filemsi":                "FileMsiType",
}

# Campi che NON devono produrre un messaggio "obbligatorio"
_SKIP_MISSING = {
    "codicemodelloantenna",   # ModelloAntennaType
    "filemsi",                # FileMsiType (padre di NomeFileMsi / GradoTilte)
    "crelprogettosrb",        # CRELProgettoSRBType (default prefissato)
    "versione",               # PraticaImpiantoCEMRLType (gestito dal backend)
}

# Etichette leggibili per le sezioni XSD (usate nei messaggi di errore)
_SECTION_LABEL = {
    "ImpiantoType":            "Impianto",
    "PuntoMisuraType":         "Punto di misura",
    "SistemaType":             "Sistema",
    "CRELProgettoSRBType":     "CREL Progetto SRB",
    "FileMsiType":             "File MSI",
    "MisuraType":              "Misura",
    "ModelloAntennaType":      "Modello antenna",
}

def _camel_from_snake(name: str) -> str:
    special = {"quota_ce": "QuotaCE", "alfa24": "Alfa24"}
    if name in special:
        return special[name]
    return _CAMEL_RE.sub(lambda m: m.group(1).upper(), name).capitalize()

def _camel_to_snake(name: str) -> str:
    name = re.sub(r'([A-Z]+)([A-Z][a-z])', r'\1_\2', name)
    name = re.sub(r'([a-z0-9])([A-Z])', r'\1_\2', name)
    return name.lower()

@lru_cache
def _schema_by_type():
    """
    Builds an index that maps (type_name, field_name) to field metadata.
    This preserves the context of where each field belongs.
    """
    path = Path(current_app.config["SCHEMA_PATH"])
    full = json.loads(path.read_text())
    complex_types = set(full.keys())
    
    index = {}
    for tname, fields in full.items():
        for f in fields:
            # Salva sempre il wrapper, sia in CamelCase che snake_case
            key_camel = (tname, f["name"])
            key_snake = (tname, _camel_to_snake(f["name"]))
            index[key_camel] = index[key_snake] = f
            
            # Se è un tipo complesso, NON scendere nei pattern
            if f.get("type") in complex_types:
                continue
    return index

def _get_parent_type(html_key: str) -> str | None:
    """
    Restituisce il tipo XSD relativo a un campo HTML.
    Scorre all'indietro nella chiave e prende il primo token NON numerico.
    Esempio:
        'impianti-0-sistemi-0-crel_progetto_srb-0-tecnologia'
                        └──────────────┬───────────────┘
                                  «crel_progetto_srb» → 'CRELProgettoSRBType'
    """
    parts = html_key.split("-")[:-1]           # esclude il vero nome campo
    for token in reversed(parts):
        if not token.isdigit():
            return _TYPE_ALIAS.get(token)
    return None

def validate(form):
    """
    Validates form fields using path-aware schema lookup.
    Returns (cleaned_dict, errors) with hierarchy-independent mapping.
    """
    log.debug("START field-validator: %d fields", len(form))
    errors, cleaned = [], {}
    seen_required = set()

    for key, raw_val in form.items():
        field_name = key.split("-")[-1]  # e.g., 'tecnologia'
        parent_type = _get_parent_type(key)
        
        if not parent_type:
            log.warning(f"No parent type found for field {key}")
            continue

        # Try both CamelCase and snake_case versions
        meta = _schema_by_type().get((parent_type, field_name)) or \
               _schema_by_type().get((parent_type, _camel_from_snake(field_name)))
        
        if not meta:
            log.debug(f"No metadata found for field {field_name} in type {parent_type}")
            continue

        val = raw_val.strip()
        if val.upper() == "TBD":
            val = ""
        
        name = meta["name"]  # Always CamelCase for consistency
        cleaned[key] = val
        
        # Track required fields
        if meta.get("required", False):
            seen_required.add(name)
            seen_required.add(field_name)

        # Required field validation
        if meta.get("required") and not val:
            errors.append({
                "field": key,
                "msg": f"Il campo «{name}» è obbligatorio"
            })
            continue

        # Pattern validation
        pat = meta.get("pattern")
        if pat and val and not re.fullmatch(pat, val):
            errors.append({
                "field": key,
                "msg": f"Il campo «{name}» non rispetta il formato"
            })

        # Allowed values validation - only if field is not empty
        if val not in (None, '', 'None'):
            allowed = meta.get("allowed_values")
            if allowed and val not in allowed:
                errors.append({
                    "field": key,
                    "msg": f"Il campo «{name}» deve essere uno dei seguenti valori: {', '.join(allowed)}"
                })

    # ------------------------------------------------------------
    # ❶  Raccogli i campi effettivamente compilati (valore non vuoto)
    # ------------------------------------------------------------
    tokens: Set[str] = set()
    for k, v in form.items():
        if v not in (None, '', [], 'TBD', '-'):
            parts = k.lower().split('-')
            collected = 0
            for p in reversed(parts):
                if p.isdigit():
                    continue
                tokens.add(p.replace('_', ''))
                collected += 1
                if collected == 2:              # bastano i 2 token più vicini
                    break
    provided = tokens

    # ------------------------------------------------------------
    # ❷  Mappa per evitare duplicati alias / label
    # ------------------------------------------------------------
    missing: dict[tuple[str, str], str] = {}  # (parent_type, canonical) → msg

    # mappa i wrapper → loro lista
    wrapper_alias = {
        'codicemodelloantenna': 'modelloantennalist',
        'filemsi':              'filemsilist',
        'crelprogettosrb':      'sistemi_list',        # basta un qualsiasi prefisso certo
        'misura':               'misurelist',
        'puntomisura':          'puntimisuralist',
        'sistema':              'sistemilist',
        'impianto':             'impiantilist',
    }

    schema_index = _schema_by_type()       # già esistente

    for (_ptype, field), meta in schema_index.items():
        if not meta.get("required"):
            continue

        # normalizza togliendo gli underscore: 'codice_gestore' -> 'codicegestore'
        norm = field.lower().replace('_', '')
        candidates = {norm}

        if meta.get("alias"):
            candidates.add(meta["alias"].lower().replace('_', ''))

        if meta.get("label"):
            candidates.add(meta["label"].lower().replace('_', ''))

        # ------------------------------------------------------------
        # salta i campi il cui input ESISTE già nel form
        # (sono stati controllati nella ❶ e, se vuoti, già segnalati)
        # ------------------------------------------------------------
        present_fields = {
            k.split("-")[-1].lower().replace('_', '')
            for k in form.keys()
        }
        if norm in present_fields:
            continue

        # se nessun candidato presente → campo mancante
        if provided.isdisjoint(candidates):
            nice        = meta.get("alias") or meta.get("label") or field
            canonical   = norm
            key_id      = (_ptype, canonical)        # de-dup per SEZIONE
            if key_id in missing:                    # già segnalato nella stessa sezione
                continue

            # salta i campi che la UX gestisce automaticamente
            if canonical in _SKIP_MISSING:
                continue

            section    = _SECTION_LABEL.get(_ptype, _ptype.replace("Type", ""))
            missing[key_id] = (
                f"Il campo «{nice}» "
                f"({section}) è obbligatorio"
            )

            # gestisci Versione
            if canonical == 'versione':
                continue    # oppure aggiungi <input type="hidden" …>

            # gestisci wrapper
            if canonical in wrapper_alias:
                # se qualunque alias è presente → wrapper soddisfatto
                if wrapper_alias[canonical] in provided:
                    continue

            # --- salta questi tre obbligatori, rimangono rossi ma non segnalati ---
            skip = {"codicemodelloantenna", "filemsi", "crelprogettosrb"}
            if canonical in skip:
                continue
            # ----------------------------------------

            current_app.logger.debug("MISS %-22s  candidates=%s  provided_sample=%s",
                                   field, sorted(candidates)[:3],  # primi 3 per brevità
                                   [p for p in list(provided)[:8]])  # primi 8 raccolti

    # non segnalare i wrapper se almeno un figlio reale è presente
    container_ok = {
        'impianto':     any('impianti_list-' in k for k in form),
        'sistema':      any('-identificativo_sistema' in k for k in form),
        'puntomisura':  any('-descrizione_punto' in k for k in form),
        'misura':       any('-valore_misurato' in k for k in form),
    }
    errors.extend(
        {"field": canonical, "msg": msg}
        for (ptype, canonical), msg in missing.items()
        if canonical not in container_ok or not container_ok[canonical]
    )

    log.debug("END field-validator: %d errors", len(errors))
    
    for err in errors:
        current_app.logger.debug("FIELD-ERROR %s → %s", err["field"], err["msg"])
    
    return cleaned, errors

def _lookup(html_key: str):
    """Lookup path-aware (chiave completa con '-')."""
    tname = _get_parent_type(html_key)
    if not tname:
        return None
    base  = html_key.split("-")[-1]
    idx   = _schema_by_type()
    return (idx.get((tname, base))
            or idx.get((tname, _camel_from_snake(base))))

def schema_required(html_key: str, parent_type: str | None = None) -> bool:
    """
    True se il campo è obbligatorio secondo lo XSD.
    - html_key: nome html (snake o path completo)
    - parent_type: tipo XSD se già noto (template -> ptype)
    """
    idx = _schema_by_type()

    if parent_type:
        base = html_key.split("-")[-1]
        meta = (idx.get((parent_type, base))
                or idx.get((parent_type, _camel_from_snake(base))))
        if not meta and base.startswith("codice_"):
            stripped = base.removeprefix("codice_")
            meta = (idx.get((parent_type, stripped))
                    or idx.get((parent_type, _camel_from_snake(stripped))))
        # fallback annidato: wrapper obbligatorio + unico figlio
        if not meta:
            wrapper = _camel_from_snake(base).replace("codice", "").capitalize()
            w_meta  = idx.get((parent_type, wrapper))
            nested  = w_meta and w_meta.get("type")
            meta    = idx.get((nested, _camel_from_snake(base))) if nested else None
    else:
        meta = _lookup(html_key)

    return bool(meta and meta.get("required"))

def schema_meta(html_key: str, parent_type: str | None = None) -> dict | None:
    """
    Ritorna il metadata completo del campo (required, type, allowed_values …).
    È un wrapper sottile sull'indice che hai già.
    """
    if parent_type:
        base = html_key.split("-")[-1]
        return _schema_by_type().get((parent_type, base)) \
            or _schema_by_type().get((parent_type, _camel_from_snake(base)))
    # fallback path-aware
    meta = _lookup(html_key)
    return meta

# Clear the schema index cache to force reload
_schema_by_type.cache_clear()