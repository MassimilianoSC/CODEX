"""
Blueprint per le route dell'applicazione.
"""
import os
import sys
import json
import re
import copy            # <-- AGGIUNGI sotto gli altri import standard
from pathlib import Path
from flask import (
    Blueprint, flash, redirect, render_template, request,
    session, url_for, current_app, jsonify
)
from werkzeug.utils import secure_filename
from xmlschema.validators.exceptions import XMLSchemaValidationError
from . import backend_bridge
from .forms import PraticaForm
from werkzeug.exceptions import RequestEntityTooLarge
from .validators.field_validator import validate as validate_fields
from backend.validators.xml_validator import XMLValidator
from backend.validators.business_rules import validate_business_rules
from lxml import etree
import pprint

# Crea un'istanza del validatore XML (usa il tuo file XSD già configurato)
_validator = XMLValidator()

# ----- dizionario tecnico → etichetta umana ----------------------
FRIENDLY_TYPE = {
    # Stringhe
    "string": "Testo libero",
    "String20": "Testo breve (max 20 caratteri)",
    "String50": "Testo breve (max 50 caratteri)",
    "String100": "Testo (max 100 caratteri)",
    "String200": "Testo (max 200 caratteri)",
    "String250": "Testo (max 250 caratteri)",
    "String500": "Testo (max 500 caratteri)",
    "Comune": "Codice comune",
    "SitoRifAlfa24": "Testo (max 100 caratteri)",  # Aggiunto per gestire il campo sito_rif_alfa_24

    # Interi
    "int": "Numero intero",
    "integer": "Numero intero",
    "Integer2": "Numero intero",
    "Integer3": "Numero intero",
    "Integer4": "Numero intero",
    "Integer7": "Numero intero",

    # Decimali
    "decimal": "Numero decimale",
    "Decimal2": "Numero decimale (2 decimali)",
    "Decimal4": "Numero decimale",
    "Decimal5-2": "Numero decimale (2 decimali)",
    "Decimal5-2S": "Numero decimale (2 decimali, segno)",
    "Decimal5-3R": "Numero decimale (3 decimali)",
    "Decimal6-2": "Numero decimale (2 decimali)",
    "Decimal6-2S": "Numero decimale (2 decimali, segno)",
    "Decimal8-3": "Numero decimale (3 decimali)",
    "Decimal9-2": "Numero decimale (2 decimali)",

    # Booleani / date / ora
    "boolean": "Sì / No",
    "date": "Data (AAAA-MM-GG)",
    "Ora": "Ora (HH:MM)",
    "Data": "Data",
    "DataType": "Data",
    "OraMisura": "Ora (HH:MM)",
    
    # Misura e unità
    "UnitaMisura": "Unità di misura",
    "UnitaMisuraType": "Unità di misura",
    "PMC": "PMC",
    "PMCType": "PMC",
    "ValoreMisurato": "Valore misurato",
    "NoteMisura": "Note della misura",
    "NoteMisuraType": "Note della misura",

    # Esposizione
    "Esposizione": "Limite esposizione",
    "EsposizioneType": "Limite esposizione",

    # Canali e frequenze
    "Canale": "Canale",
    "FrequenzaMin": "Frequenza minima",
    "FrequenzaMax": "Frequenza massima",

    # Tipologie
    "TipoMisura": "Tipo Misura",
    "TipoMisuraType": "Tipo Misura",
    "TipoPratica": "Tipo Pratica",
    "TipoPraticaType": "Tipo Pratica",
    "TipoAntenna": "Tipo Antenna",

    # Modelli
    "ModelloAntenna": "ModelloAntenna",
    "ModelloAntennaType": "ModelloAntenna",

    # Altro
    "PseudoCodiceFiscale": "Codice gestore",
    "PseudoCodiceFiscaleType": "Codice gestore",
    "PolarizzazioneType": "Polarizzazione",
    "Tecnologia": "Tecnologia",
    "TecnologiaType": "Tecnologia",

    "DataMisura": "Data (YYYY-MM-DD)",
    "OraMisura": "Ora (HH:MM)",
    "UnitaMisura": "Unità di misura",
    "ValoreMisurato": "Valore numerico misurato",
    "Canale": "Numero canale",
    "FrequenzaMin": "Frequenza minima (MHz)",
    "FrequenzaMax": "Frequenza massima (MHz)",
    "Rho": "Rapporto segnale/rumore",
    "Nrs": "Numero riferimento segnale",
    "Bf": "Fattore Bf",
    "Alfa24Max": "Alfa24 (valore massimo)",
    "Alfa24Day": "Alfa24 (media diurna)",
    "NoteMisura": "Note relative alla misura",
    "PMC": "Piano di Monitoraggio Comunale",
    "TipoMisura": "Tipo di misura",
    "Polarizzazione": "Polarizzazione. Valori: 1–8",
    "ProvinceLiguri": "Provincia ligure",
    "SiNo": "Sì / No",


}

# campi con menu a tendina: non mostrare "Valori ammessi"
FIELDS_HIDE_VALUES = {
    "tipo_antenna",
    "tacs",
    "limite_esposizione",
    "tipo_misura",
    "pmc",
}

# --- CARICA E FLATTA LO SCHEMA UNA SOLA VOLTA --------------------
_SCHEMA_PATH = (
    Path(__file__).resolve().parents[1]
    / "backend" / "schema" / "schemas" / "combined_schema.json"
)
_schema_data = json.loads(_SCHEMA_PATH.read_text(encoding="utf-8"))

def _flatten_schema(schema: dict) -> dict[str, dict]:
    """
    Converte il JSON gerarchico in un dizionario:
    snake_case -> {required, type, allowed_values, …}
    utile per lookup veloce.
    """
    import re
    def camel_to_snake(name: str) -> str:
        """
        Converte CamelCase in snake_case mantenendo compatte le sigle:
        QuotaCE -> quota_ce
        AlfaDTX -> alfa_dtx
        SitoRifAlfa24 -> sito_rif_alfa24
        """
        name = re.sub(r'([A-Z]+)([A-Z][a-z])', r'\1_\2', name)  # CEQuota -> CE_Quota
        name = re.sub(r'([a-z0-9])([A-Z])', r'\1_\2', name)     # quotaCE -> quota_CE
        return name.lower()

    flat = {}
    def walk(block: list[dict], seen: set[str] = None):
        if seen is None:
            seen = set()

        for f in block:
            key = camel_to_snake(f["name"])
            if f.get("type"):
                flat[key] = f

            tipo = f.get("type")
            if not tipo:
                continue

            # Prima esplora, poi marca come già visto
            if tipo in schema and tipo not in seen:
                walk(schema[tipo], seen)
                seen.add(tipo)

            elif tipo.endswith("Type"):
                base = tipo[:-4]
                if base in schema and base not in seen:
                    walk(schema[base], seen)
                    seen.add(base)

    # Chiamata esplicita alla funzione walk
    walk(schema["PraticaImpiantoCEMRLType"])
    # 🔥 Aggiunga esplicita dei blocchi figli usati in liste
    for tipo in ("PuntoMisuraType", "Misura", "MisuraType", "TipoMisuraType", 
                 "PMCType", "TecnologiaType", "CRELProgettoSRBType"):
        if tipo in schema:
            walk(schema[tipo])

    print("=== CHIAVI _FIELD_META DISPONIBILI ===")
    for k in sorted(flat.keys()):
        print(k)
    print("=======================================")

    return flat


# Aggiungi il dizionario degli alias
ALIAS = {
    "quota_base": "quota",
    "quota": "quota",
    "unita_misura": "UnitaMisura",
    "ora_misura": "OraMisura",
    "unita_misura": "UnitaMisura"
}

_FIELD_META = _flatten_schema(_schema_data)

bp = Blueprint('main', __name__)

def validate_required_fields(form): 
    missing = [] 

    def check_form_fields(form_section, path=""): 
        for field in form_section: 
            field_path = f"{path}.{field.name}" if path else field.name 
            if hasattr(field, 'entries') and field.entries: 
                # Se è una FieldList (es: Sistemi, Misure, ecc.) 
                for entry in field.entries: 
                    check_form_fields(entry, path=field_path) 
            else: 
                if getattr(field, "flags", None) and "required" in getattr(field.flags, "__dict__", {}): 
                    # ✨ Modifica qui: considera valido anche 0 o "0" 
                    if field.data in ("", None) or (isinstance(field.data, str) and not field.data.strip()): 
                        missing.append(field_path) 

    check_form_fields(form) 
    return missing 

# ----------------------------------------------------
def allowed_file(filename: str) -> bool:
    """Verifica se il file ha estensione .xml consentita."""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() == 'xml'

def handle_add_sistema(form):
    """Helper per gestire l'aggiunta di un nuovo sistema nel form."""
    for impianto_form in form.impianti_list:
        if impianto_form.add_sistema.data:
            impianto_form.sistemi.append_entry()
            # Imposta valore di default se necessario
            new_sys = impianto_form.sistemi[-1]
            if hasattr(new_sys, "tipo_crel"):
                new_sys.tipo_crel.data = "CRELProgettoSRB"
            return True
    return False




def load_help_texts():
    from wtforms.fields import FieldList, FormField
    from wtforms.form import Form

    help_texts = {}
    form = PraticaForm()

    # Forza almeno una entry per ciascun campo lista (per generare campi dinamici)
    if form.impianti_list and not form.impianti_list[0].sistemi.entries:
        form.impianti_list[0].sistemi.append_entry()

    if form.impianti_list and not form.impianti_list[0].punti_misura.entries:
        form.impianti_list[0].punti_misura.append_entry()

    for punto in form.impianti_list[0].punti_misura.entries:
        if not punto.misure_list.entries:
            punto.misure_list.append_entry()

    def walk_fields(field, fn):
        if isinstance(field, FieldList):
            if field.entries:
                for entry in field.entries:
                    walk_fields(entry, fn)
            else:
                proto = field.unbound_field
                if isinstance(proto, FormField):
                    proto_form = proto.form_class()
                    for sub in proto_form:
                        walk_fields(sub, fn)
                else:
                    fn(proto)
            return
        if isinstance(field, FormField):
            walk_fields(field.form, fn)
            return
        if isinstance(field, Form):
            for sub in field:
                walk_fields(sub, fn)
            return
        fn(field)

    def to_camel_case(snake_str):
        components = snake_str.split('_')
        return ''.join(x.title() for x in components)

    def process_field(field):
        if not getattr(field, "name", None):
            return

        full_path = field.name.replace("-", ".")
        base = field.name.split("-")[-1]
        tried_keys = [base]

        # Tentativi per trovare il campo nei metadati
        candidates = [
            ALIAS.get(base, None),
            to_camel_case(base),
            base
        ]
        candidates = [c for c in candidates if c]

        for key in candidates:
            fld = _FIELD_META.get(key)
            if fld:
                break
        else:
            fld = {}

        raw_type = fld.get("type")
        if raw_type:
            key_type = raw_type.removesuffix("Type")
            tipo = FRIENDLY_TYPE.get(key_type, key_type)
        elif base in ALIAS:
            tipo = FRIENDLY_TYPE.get(ALIAS[base], "—")
        else:
            tipo = "—"

        parts = [
            "Campo obbligatorio." if fld.get("required") else "Campo opzionale.",
            f"Tipo: {tipo}."
        ]

        allowed = fld.get("allowed_values")
        if allowed:
            parts.append("Valori ammessi: " + ", ".join(map(str, allowed)) + ".")

        help_text = " ".join(parts)
        help_texts[base] = help_text
        help_texts[full_path] = help_text

    walk_fields(form, process_field)
    return help_texts


@bp.route('/')
def index():
    """Pagina principale con opzioni per caricare o creare una nuova pratica."""
    return render_template('index.html')

@bp.route('/new', methods=['GET', 'POST'])
def new_pratica():
    """Crea una nuova pratica vuota, resettando qualsiasi pratica esistente in sessione."""
    session.pop('pratica', None)
    session.pop('filepath', None)

    pratica = backend_bridge.create_new_pratica()
    filename = secure_filename('nuova_pratica.xml')
    filepath = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
    backend_bridge.save_xml(pratica, filepath, validate=False)
    session['filepath'] = filepath
    session['pratica'] = pratica        # prima del redirect

    form = PraticaForm()
    
    # 🔥 Aggiungi almeno un Sistema vuoto
    if form.impianti_list and not form.impianti_list[0].sistemi.entries:
        form.impianti_list[0].sistemi.append_entry()

    if form.impianti_list and not form.impianti_list[0].punti_misura.entries:
        form.impianti_list[0].punti_misura.append_entry()

    for punto in form.impianti_list[0].punti_misura.entries:
        if not punto.misure_list.entries:
            punto.misure_list.append_entry()

    if request.method == 'POST':
        if handle_add_sistema(form):
            return render_template("pratica_edit.html", form=form, help_texts=load_help_texts(), hide_zero=True)
        if form.validate_on_submit() and form.submit.data:
            flash('Pratica salvata con successo', 'success')
            return redirect(url_for('main.index'))

    flash('Nuova pratica creata', 'info')
    return redirect(url_for('main.edit', impianto=0, sistema=0))

@bp.route('/open', methods=['POST'])
def open_file():
    """Gestisce l'upload di un file XML."""
    current_app.logger.debug(">>> ENTER %s", __name__)

    if 'file' not in request.files:
        flash('❌ Nessun file selezionato', 'error')
        return redirect(url_for('main.index'))

    file = request.files['file']
    if file.filename == '':
        flash('❌ Nessun file selezionato', 'error')
        return redirect(url_for('main.index'))

    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        filepath = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)

        # Validazione del file XML - non blocchiamo più in caso di errori
        xsd_errors = backend_bridge.validate_xml_file(filepath)

        try:
            # Read the XML content and store it in session
            with open(filepath, "r", encoding="utf-8") as fh:
                xml_content = fh.read()
            session['current_xml'] = xml_content
            
            pratica = backend_bridge.open_xml(filepath)
            session['pratica'] = pratica
            session['filepath'] = filepath
            
            # Se c'erano errori XSD, mostriamo un warning
            if xsd_errors:
                flash(
                    "⚠ Il file non è conforme allo schema.<br>"
                    "È stato caricato lo stesso: premi «Validazione XSD» per i dettagli.",
                    "warning"
                )
            
            flash(f'✅ File {filename} caricato con successo', 'success')
            return redirect(url_for('main.edit', impianto=0, sistema=0))
        except Exception as e:
            current_app.logger.exception("!!! ERROR in %s", __name__)
            flash(f'❌ Errore inatteso durante il parsing: {e}', 'danger')
            return redirect(url_for('main.index'))

    flash('❌ Formato file non supportato. Caricare solo file XML.', 'error')
    return redirect(url_for('main.index'))

@bp.route('/edit')
def edit():
    """
    Editor paginato: 1 Impianto alla volta e, all'interno, 1 Sistema alla volta.
    Parametri query:
        ?impianto=N&sistema=M
    """
    pratica_all: dict = session.get('pratica') or backend_bridge.create_new_pratica()
    session['pratica'] = pratica_all        # coerenza

    def as_list(node):
        """
        • se node è già una list → la restituisce
        • se è un dict con **tutte** le chiavi numeriche ("0","1",…) → lista ordinata
        • in tutti gli altri casi → lista con il dict stesso (singolo elemento)
        """
        if isinstance(node, list):
            return node

        if isinstance(node, dict):
            if all(str(k).isdigit() for k in node.keys()):
                # dict che rappresenta davvero una lista
                keys = sorted(node.keys(), key=int)
                return [node[k] for k in keys]
            # dict "normale" → un solo elemento
            return [node]

        # qualunque altro tipo (stringa, None, …)
        return []

    # ── indici da query string ─────────────────────────────
    imp_idx = int(request.args.get("impianto", 0))
    sys_idx = int(request.args.get("sistema", 0))

    # ── impianti & sistemi in forma di lista ──────────────
    impianti = as_list(pratica_all.get("Impianto")) or [{}]
    imp_idx  = max(0, min(imp_idx, len(impianti) - 1))

    # ➜ se l'elemento non è un dict (può capitare con XML errati) lo sostituiamo
    impianto_node = impianti[imp_idx] if isinstance(impianti[imp_idx], dict) else {}

    sistemi_all = as_list(impianto_node.get("Sistema")) or [{}]
    sys_idx  = max(0, min(sys_idx, len(sistemi_all) - 1))

    # ── ritaglio "leggero" -------------------------------
    import copy

    impianto_copy = copy.deepcopy(impianto_node)
    # passa al template *tutti* i sistemi
    impianto_copy["Sistema"] = copy.deepcopy(sistemi_all)

    pratica_light = {
        "TipoPratica": pratica_all.get("TipoPratica"),
        "NotePratica": pratica_all.get("NotePratica"),
        # se in futuro aggiungi altri campi di header, copiali qui …
        "Impianto": [impianto_copy],
    }

    # ── navigazione / context ----------------------------
    view_ctx = dict(
        idx=imp_idx,
        tot_impianti=len(impianti),
        tot_sistemi=len(sistemi_all),
        prev_idx=imp_idx - 1 if imp_idx > 0 else None,
        next_idx=imp_idx + 1 if imp_idx < len(impianti) - 1 else None,
    )

    # ―――――――― FORM ――――――――――――――――――――――――――――――――――――――――
    form = PraticaForm()
    backend_bridge.populate_form_from_pratica(form, pratica_light)
    impianto_form = form.impianti_list[0]

    return render_template(
        "pratica_edit.html",
        form=form,
        impianto_form=impianto_form,
        help_texts=load_help_texts(),
        hide_zero=False,  # Show zeros for existing practices
        **view_ctx,
    )

@bp.route('/validate/xsd', methods=['POST'])
def validate_xsd():
    current_app.logger.debug('[DBG-API] validate_xsd chiamato, bytes=%d', request.content_length or 0)
    
    # 1) controllo campi singoli (messaggi user-friendly)
    cleaned, field_err = validate_fields(request.form)
    if field_err:
        return jsonify(ok=False, stage="fields", errors=field_err)

    # 2) costruzione XML + validazione XSD
    xml_string = backend_bridge.build_xml_from_form(request.form)
    xsd_errors = _validator.validate_string(xml_string) or []  # Normalizza sempre in lista
    ok = not xsd_errors

    return jsonify(
        ok=ok,
        stage="xsd",
        errors=xsd_errors  # Mai più None
    )

@bp.route('/validate_business', methods=['POST'])
def validate_business():
    current_app.logger.debug('[DBG-API] validate_business chiamato, bytes=%d', request.content_length or 0)
    try:
        xml_string = backend_bridge.build_xml_from_form(request.form)
        if not xml_string:
            return jsonify(
                ok=False,
                stage="business",
                errors=[{"msg": "Impossibile generare l'XML dal form"}]
            )
        errors = validate_business_rules(xml_string)
        return jsonify(
            ok=len(errors) == 0,
            stage="business",
            errors=errors or []  # Ensure errors is always a list
        )
    except Exception as e:
        current_app.logger.error('Errore validazione business: %s', str(e))
        return jsonify(
            ok=False,
            stage="business",
            errors=[{"msg": f"Errore durante la validazione business: {str(e)}"}]
        )


# Aggiungi questo set vicino a FRIENDLY_TYPE
FIELDS_WITH_DROPDOWN = {
    "tipo_antenna",
    "tacs",
    "limite_esposizione",
    "tipo_misura",
    "pmc",
    "tecnologia"  # aggiunto nuovo campo
}

@bp.route('/save', methods=['POST'])
def save():
    print("\n===== INIZIO DEBUG_FORM_KEYS =====")
    print("🔍 DEBUG_FORM_KEYS: elenco chiavi ricevute dal form:")
    for k in request.form.keys():
        print("    🔍 DEBUG_FORM_KEYS:", k)
    print("===== FINE DEBUG_FORM_KEYS =====\n")
    """Salva il modello corrente in un file XML."""
    pratica = session.get('pratica')
    if pratica is None:
        pratica = backend_bridge.create_new_pratica()
        session['pratica'] = pratica

    ### ── COMBINED_SCHEMA VALIDATION ───────────────────────────
    # 1. controlliamo i campi con il validator che legge combined_schema
    cleaned, field_err = validate_fields(request.form)
    if field_err:                                         # messaggi già "friendly"
        return jsonify(ok=False, stage="fields", errors=field_err), 200
    ### ── fine validazione campi • se arriva qui, possiamo salvare ──

    # 2. (opzionale) WTForms – ora senza InputRequired:
    form = PraticaForm(request.form)
    print("🔍 DEBUG_FORM_ENTRIES: punti_misura entries =", len(form.impianti_list[0].punti_misura.entries))
    for idx, p in enumerate(form.impianti_list[0].punti_misura.entries):
        print(f"🔍 DEBUG_FORM_ENTRIES: punto {idx} codifica_gestore =", p.codifica_gestore.data)
        print(f"🔍 DEBUG_FORM_ENTRIES: misure_list entries =", len(p.misure_list.entries))
        for midx, m in enumerate(p.misure_list.entries):
            print(f"    🔍 DEBUG_FORM_ENTRIES: misura {midx} tipo_misura =", m.tipo_misura.data)

    if not form.validate():
        current_app.logger.debug("WTForms non valido: %s", form.errors)
        # NON faccio return, continuo

    pratica = backend_bridge.update_pratica_from_form(pratica, form)
    #print("[DEBUG] Dopo update_pratica_from_form - pratica creata")
    session['pratica'] = pratica

    filepath = session.get('filepath')
    if not filepath:
        filename = secure_filename('nuova_pratica.xml')
        filepath = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
        session['filepath'] = filepath

    try:
        errors = backend_bridge.save_xml(pratica, filepath)
        print("[DEBUG] Dopo save_xml - errors:", errors)
        if errors:
            return jsonify({
                'success': False,
                'message': '❌ Errori di validazione XML',
                'errors': errors
            }), 400

        return jsonify({
            'success': True, 
            'message': f"✅ Pratica salvata correttamente! Percorso: {filepath}"
        })
    except Exception as e:
        return jsonify({
            'success': False, 
            'message': f"❌ {str(e)}"
        }), 500

@bp.route('/field_info/<path:field_name>')
def field_info(field_name):
    """Restituisce le informazioni sul campo per il tooltip."""
    # Prova prima con l'alias se presente
    base = field_name.split('.')[-1]  # prendi l'ultima parte del path
    key = ALIAS.get(base, base)
    fld = _FIELD_META.get(key, {})
    
    if fld == {}:
        print("DEBUG meta mancante:", base)
        
    field_type = fld.get("type", "")
    friendly = FRIENDLY_TYPE.get(field_type, "Testo libero" if fld == {} else field_type)
    
    allowed = []
    if "allowed_values" in fld and field_name not in FIELDS_HIDE_VALUES:
        allowed = fld["allowed_values"]
    
    return {
        "type": friendly,
        "required": fld.get("required", False),
        "allowed_values": allowed
    }

    

