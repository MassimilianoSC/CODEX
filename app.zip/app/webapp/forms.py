# app/webapp/forms.py

from flask_wtf import FlaskForm
from wtforms import (
    StringField, IntegerField, FloatField,
    SelectField, FieldList, FormField, SubmitField, DecimalField
)
from wtforms.validators import Optional, DataRequired

from app.backend.models.pratica_model import (
    TipoPratica, TipoMisura, PMC,
    TipoAntenna, Tecnologia, SiNo, LimiteEsposizione
)
from app.backend.models.enums import TECNOLOGIATYPE, PMCTYPE
from .crel_forms import SistemaForm  # import the new SistemaForm

# Child forms
class MisuraForm(FlaskForm):
    tipo_misura = SelectField(
        "Tipo Misura",
        choices=[('', '—')] + [(str(m.value), m.name) for m in TipoMisura],
        coerce=str,
        validate_choice=False,
        validators=[Optional()]
    )
    data_misura = StringField("Data Misura (YYYY-MM-DD)", validators=[Optional()])
    ora_misura = StringField("Ora Misura (HH:MM)", validators=[Optional()])
    pmc = SelectField(
        "PMC",
        choices=[(str(p.value), p.name) for p in PMCTYPE],
        coerce=str,
        validators=[DataRequired()]
    )
    unita_misura = StringField("Unità Misura", validators=[Optional()])
    valore_misurato = FloatField("Valore Misurato", validators=[Optional()])
    tecnologia = SelectField(
        "Tecnologia",
        choices=[('', '—')] + [(str(t.value), t.name) for t in TECNOLOGIATYPE],
        coerce=str,
        validate_choice=False,
        validators=[Optional()]
    )
    settore = StringField("Settore", validators=[Optional()])
    canale = IntegerField("Canale", validators=[Optional()])
    frequenza_min = FloatField("Frequenza Min", validators=[Optional()])
    frequenza_max = FloatField("Frequenza Max", validators=[Optional()])
    alfa_pc = FloatField("Alfa PC", validators=[Optional()])  # AlfaPC
    alfa_dtx = FloatField("Alfa DTX", validators=[Optional()])  # AlfaDTX
    rho = FloatField("Rho", validators=[Optional()])
    nrs = FloatField("NRS", validators=[Optional()])
    bf = FloatField("BF", validators=[Optional()])
    alfa24_max = FloatField("Alfa24 Max", validators=[Optional()])
    alfa24_day = FloatField("Alfa24 Day", validators=[Optional()])
    note_misura = StringField("Note Misura", validators=[Optional()])

class PuntoMisuraForm(FlaskForm):
    codifica_gestore = StringField("Codifica Gestore", validators=[Optional()])
    descrizione_punto = StringField("Descrizione Punto", validators=[Optional()])
    coordinata_x = IntegerField("Coordinata X", validators=[Optional()])
    coordinata_y = IntegerField("Coordinata Y", validators=[Optional()])
    quota = FloatField("Quota", validators=[Optional()])
    distanza = FloatField("Distanza", 
                         default='0',
                         validators=[Optional()], 
                         render_kw={"step": "any"})
    direzione = FloatField("Direzione", 
                          default='0',
                          validators=[Optional()], 
                          render_kw={"step": "any"})
    dislivello = FloatField("Dislivello", validators=[Optional()])
    limite_esposizione = SelectField(
        "Limite Esposizione",
        choices=[('', '—')] + [(str(e.value), e.name) for e in LimiteEsposizione],
        coerce=str,
        validate_choice=False,
        validators=[Optional()]
    )
    fattore_attenuazione = FloatField("Fattore Attenuazione", validators=[Optional()])
    note_fattore_attenuazione = StringField("Note Fattore Attenuazione", validators=[Optional()])
    misure_list = FieldList(
        FormField(MisuraForm),
        min_entries=1,
        label="Misure"
    )

class ImpiantoForm(FlaskForm):
    codice_gestore = StringField("Codice Gestore", validators=[Optional()])
    descrizione = StringField("Descrizione", validators=[Optional()])
    ragione_sociale = StringField("Ragione Sociale", validators=[Optional()])
    identificativo_impianto = StringField("Identificativo Impianto", validators=[Optional()])
    data_inizio_gestione = StringField("Data Inizio Gestione (YYYY-MM-DD)", validators=[Optional()])
    proto_concessione_ministeriale = StringField("Proto Concessione Ministeriale", validators=[Optional()])
    cod_prov = StringField("Codice Provincia", validators=[Optional()])
    cod_com = StringField("Codice Comune", validators=[Optional()])
    indirizzo_localita = StringField("Indirizzo Località", validators=[Optional()])
    coordinata_x = IntegerField("Coordinata X", validators=[Optional()])
    coordinata_y = IntegerField("Coordinata Y", validators=[Optional()])
    quota_base = FloatField("Quota Base", validators=[Optional()])
    note_impianto = StringField("Note Impianto", validators=[Optional()])
    referente = StringField("Referente", validators=[Optional()])

    # Sostituito con SistemaForm che include CRELProgettoSRB
    sistemi = FieldList(
        FormField(SistemaForm),
        min_entries=1,
        label="Sistemi"
    )
    
    # Aggiungiamo il campo punti_misura che mancava
    punti_misura = FieldList(
        FormField(PuntoMisuraForm),
        min_entries=1,
        label="Punti di Misura"
    )
    
    add_sistema = SubmitField("+ Aggiungi Sistema")

class PraticaForm(FlaskForm):
    tipo_pratica = SelectField(
        "Tipo Pratica",
        choices=[('', '—')] + [(str(t.value), t.name) for t in TipoPratica],
        coerce=str,
        validate_choice=False,
        validators=[Optional()],
    )
    note_pratica = StringField("Note Pratica", validators=[Optional()])
    impianti_list = FieldList(
        FormField(ImpiantoForm),
        min_entries=1,
        label="Impianti"
    )
    submit = SubmitField("Salva")

class FileMsiForm(FlaskForm):
    grado_tilte = IntegerField("GradoTilte", validators=[DataRequired()])
    nome_file_msi = StringField("NomeFileMsi", validators=[DataRequired()])

class CRELProgettoSRBForm(FlaskForm):
    tipo_antenna = SelectField("TipoAntenna", validators=[DataRequired()])
    modello_antenna = StringField("ModelloAntenna", validators=[DataRequired()])
    tecnologia = SelectField("Tecnologia", validators=[DataRequired()])
    settore = StringField("Settore")
    azimut = IntegerField("Azimut", validators=[DataRequired()])
    quota_ce = DecimalField("QuotaCE", validators=[DataRequired()])
    tilte = DecimalField("Tilte", validators=[DataRequired()])
    tilte_min = DecimalField("TilteMin", validators=[DataRequired()])
    tilte_max = DecimalField("TilteMax", validators=[DataRequired()])
    tiltm = DecimalField("Tiltm", validators=[DataRequired()])
    tiltm_min = DecimalField("TiltmMin", validators=[DataRequired()])
    tiltm_max = DecimalField("TiltmMax", validators=[DataRequired()])
    num_portanti_attivabili = IntegerField("NumPortantiAttivabili", validators=[DataRequired()])
    potenza_totale_connettore = DecimalField("PotenzaTotaleConnettore", validators=[DataRequired()])
    potenza_irradiata_connettore = DecimalField("PotenzaIrradiataConnettore")
    fpr = DecimalField("Fpr")
    ftc = DecimalField("Ftc")
    alfa24 = DecimalField("Alfa24", validators=[DataRequired()])
    alfa_pc = DecimalField("AlfaPC", validators=[DataRequired()])
    alfa_dtx = DecimalField("AlfaDTX", validators=[DataRequired()])
    eirp = DecimalField("Eirp", validators=[DataRequired()])
    guadagno = DecimalField("Guadagno", validators=[DataRequired()])
    potenza_nominale = DecimalField("PotenzaNominale")
    perdita_trasmissione = DecimalField("PerditaTrasmissione")
    polarizzazione = SelectField("Polarizzazione")
    sito_rif_alfa_24 = StringField("SitoRifAlfa24")
    coordinata_x = IntegerField("CoordinataX")
    coordinata_y = IntegerField("CoordinataY")
    coordinata_z = DecimalField("CoordinataZ")
    file_msi = FieldList(FormField(FileMsiForm), min_entries=0)
