"""
Factory pattern per creare l'applicazione Flask.
"""
from __future__ import annotations

import os
import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
from flask import Flask, request
from flask_wtf import CSRFProtect
from flask_session import Session  # New import for Flask-Session

log = logging.getLogger(__name__)

def create_app(test_config: dict | None = None) -> Flask:
    app = Flask(__name__,
                instance_relative_config=True,
                static_folder="static",
                template_folder="templates")

    # 1️⃣ Attiva subito DEBUG per app.logger
    app.logger.setLevel(logging.DEBUG)

    # ── percorso al combined_schema.json ─────────────────────────────
    from pathlib import Path
    BASEDIR = Path(__file__).resolve().parents[1]          # …/app/
    app.config["SCHEMA_PATH"] = (BASEDIR / "backend" / "schema" /
                                 "schemas" / "combined_schema.json")

    # Configurazione base dell'applicazione
    app.config.from_mapping(
        SECRET_KEY=os.environ.get("SECRET_KEY", "dev"),
        UPLOAD_FOLDER=Path(app.instance_path) / "uploads",
        SESSION_TYPE="filesystem",  # Configure session storage
        SESSION_FILE_DIR=Path(app.instance_path) / "flask_sessions",
        SESSION_PERMANENT=False  # Use session cookies
    )

    # ------------------- PRIMA di app.config.from_pyfile -------------------
    app.logger.info("MAX_CONTENT_LENGTH (prima di config esterna): %s", 
                    app.config["MAX_CONTENT_LENGTH"])
    # ----------------------------------------------------------------------

    # Configurazione di runtime/test
    if test_config is None:
        app.config.from_pyfile("config.py", silent=True)
    else:
        app.config.update(test_config)

    # ------------------- DOPO app.config.from_pyfile / test_config --------
    app.logger.info("MAX_CONTENT_LENGTH (dopo config esterna): %s", 
                    app.config["MAX_CONTENT_LENGTH"])
    # ----------------------------------------------------------------------

    # ⬇︎ qui è il punto GIUSTO: qualunque file esterno lo ha già "sporco"
    app.config.update(
        MAX_CONTENT_LENGTH=100 * 1024 * 1024,  # 100 MB totali
        MAX_FORM_MEMORY_SIZE=32 * 1024 * 1024,  # 32 MB per i campi non-file
        MAX_FORM_PARTS=20_000,  # Aumenta il limite delle parti del form
    )

    # ---------- Crea (se necessarie) le cartelle ----------
    Path(app.instance_path).mkdir(parents=True, exist_ok=True)      # ② Path(...)
    app.config["UPLOAD_FOLDER"].mkdir(parents=True, exist_ok=True)  # è già Path
    app.config["SESSION_FILE_DIR"].mkdir(parents=True, exist_ok=True)  # Create sessions directory

    # Initialize Flask-Session
    Session(app)
    csrf = CSRFProtect()
    csrf.init_app(app)

    from flask_wtf.csrf import generate_csrf

    @app.context_processor
    def inject_csrf_token():
        """Espone csrf_token() nei template che NON usano WTForms."""
        return dict(csrf_token=generate_csrf)

    # Add request/response logging
    @app.before_request
    def _log_request():
        app.logger.debug("REQ %s %s Content-Length=%s  parts=%s", 
                         request.method, 
                         request.path, 
                         request.content_length,
                         request.max_form_parts)

    @app.after_request
    def _log_response(resp):
        app.logger.debug("RESP %s %s", resp.status, resp.mimetype)
        return resp

    # ---------- Blueprint ----------
    from . import routes
    app.register_blueprint(routes.bp)
    app.add_url_rule("/", endpoint="index")

    # Register schema_required as a global Jinja template helper
    from .validators.field_validator import schema_required, schema_meta
    app.jinja_env.globals["schema_required"] = schema_required
    app.jinja_env.globals["schema_meta"] = schema_meta

    # Enhanced logging setup
    import sys                    # logging è già in cima al file
    from logging.handlers import RotatingFileHandler

    app.logger.setLevel(logging.DEBUG)          # il logger emette DEBUG+

    # ——— file handler ———
    fh = RotatingFileHandler(
        "instance/app.log",
        maxBytes=5 * 1024 * 1024,
        backupCount=3,
        encoding="utf-8"         # <— evita UnicodeEncodeError
    )
    fh.setLevel(logging.DEBUG)   # <— accetta DEBUG+
    app.logger.addHandler(fh)

    # ——— console handler (opzionale ma consigliato in dev) ———
    ch = logging.StreamHandler(stream=sys.stdout)  # no 'encoding' in Py ≤ 3.11
    ch.setLevel(logging.DEBUG)
    app.logger.addHandler(ch)

    # TODO: Spostare la logica degli error handler in un modulo errors.py per maggiore pulizia
    @app.errorhandler(413)
    def request_entity_too_large(error):
        app.logger.warning("Upload troppo grande da %s", request.remote_addr)
        return "File troppo grande", 413

    # Carica combined_schema.json una sola volta 
    import json
    app.config["FIELD_SCHEMA"] = json.loads(
        app.config["SCHEMA_PATH"].read_text(encoding="utf-8")
    )

    # Verifica finale dei limiti
    app.logger.debug("== LIMITI ==>  MAX_CONTENT_LENGTH=%s   MAX_FORM_MEMORY_SIZE=%s   MAX_FORM_PARTS=%s",
                    app.config.get("MAX_CONTENT_LENGTH"),
                    app.config.get("MAX_FORM_MEMORY_SIZE"),
                    app.config.get("MAX_FORM_PARTS"))

    return app